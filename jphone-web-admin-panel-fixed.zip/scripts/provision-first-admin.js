/**
 * JPhone Admin Web - First Administrator Provisioning Script
 * 
 * Run from a trusted administrative environment using Firebase Admin SDK:
 * node scripts/provision-first-admin.js <admin_uid> [admin_email]
 */

const admin = require('firebase-admin');
const path = require('path');

// Locate service account credentials
const serviceAccountPath = process.env.GOOGLE_APPLICATION_CREDENTIALS || path.join(__dirname, '../service-account.json');

try {
  const serviceAccount = require(serviceAccountPath);
  admin.initializeApp({
    credential: admin.credential.cert(serviceAccount)
  });
} catch (e) {
  console.error('\x1b[31mError loading Google Cloud Service Account credentials.\x1b[0m');
  console.error('Please ensure GOOGLE_APPLICATION_CREDENTIALS environment variable is set or place service-account.json in the project root.\n');
  process.exit(1);
}

const db = admin.firestore();

async function main() {
  const targetUid = process.argv[2];
  const targetEmail = process.argv[3] || 'attamuhammad6008@gmail.com';

  if (!targetUid) {
    console.error('\x1b[33mUsage: node scripts/provision-first-admin.js <FIREBASE_AUTH_UID> [EMAIL]\x1b[0m');
    console.error('Example: node scripts/provision-first-admin.js Abc123UidXYZ attamuhammad6008@gmail.com\n');
    process.exit(1);
  }

  console.log(`\nProvisioning Super Admin for JPhone ecosystem:`);
  console.log(`UID:   ${targetUid}`);
  console.log(`Email: ${targetEmail}`);

  const adminRef = db.collection('admins').doc(targetUid);
  await adminRef.set({
    id: targetUid,
    email: targetEmail,
    role: 'super_admin',
    assignedBy: 'system_bootstrap',
    assignedAt: new Date().toISOString(),
    active: true
  });

  // Also set custom claim for double-check authorization
  try {
    await admin.auth().setCustomUserClaims(targetUid, { admin: true, role: 'super_admin' });
    console.log('Firebase Auth custom claims updated.');
  } catch (err) {
    console.warn('Note: Could not set custom claims via Auth, Firestore record established.');
  }

  console.log('\x1b[32m✔ Successfully provisioned Super Administrator in /admins collection!\x1b[0m\n');
}

main().catch(err => {
  console.error('Failed to provision administrator:', err);
  process.exit(1);
});
