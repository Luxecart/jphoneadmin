# JPhone Android Application Integration Guide

This document details how the **JPhone Android Application** consumes settings, verifies subscription entitlements, and fixes the `CONFIGURATION_NOT_FOUND` error.

---

## 1. Fixing `CONFIGURATION_NOT_FOUND` in Android Phone Auth

The error `com.google.firebase.FirebaseException: [CONFIGURATION_NOT_FOUND]` happens when `PhoneAuthProvider.verifyPhoneNumber()` is executed on Android without complete Firebase Console setup.

### Exact Resolution Steps:

1. **Enable Phone Authentication Provider**:
   - Go to [Firebase Console](https://console.firebase.google.com/) > **Authentication** > **Sign-in method**.
   - Click **Phone** > toggle **Enable** > click **Save**.

2. **Add Android SHA-1 & SHA-256 Fingerprints**:
   - In Android Studio, open the terminal and execute:
     ```bash
     ./gradlew signingReport
     ```
   - Copy both the **SHA-1** and **SHA-256** certificate fingerprints.
   - Go to **Project Settings** > **General** > **Your apps** > Select your Android app (`com.aistudio.jphone.qkzvtb`).
   - Click **Add fingerprint** and paste both SHA-1 and SHA-256 keys.
   - *Note for Google Play App Signing*: If published to Play Store, copy the SHA-1 from **Google Play Console** > **Setup** > **App integrity** > **App signing key certificate**.

3. **Enable Identity Toolkit & Play Integrity APIs in Google Cloud Console**:
   - In [Google Cloud Console](https://console.cloud.google.com/), confirm that:
     - `Identity Toolkit API` is enabled.
     - `Play Integrity API` is enabled.

4. **Verify Package Name in `google-services.json`**:
   - Confirm `package_name: "com.aistudio.jphone.qkzvtb"` matches `applicationId "com.aistudio.jphone.qkzvtb"` in `app/build.gradle`.
   - Download the updated `google-services.json` and replace `app/google-services.json`.

5. **Test Phone Numbers for Development**:
   - In Firebase Console > Authentication > Phone > **Phone numbers for testing**, add:
     - Phone: `+923000000000`
     - Verification code: `123456`
   - Test numbers bypass SMS gateway charges and work immediately in Android emulators.

---

## 2. Consuming Remote Settings in Android (Kotlin)

The JPhone Android client observes document `/settings/general` in Cloud Firestore:

```kotlin
class RemoteConfigRepository(private val db: FirebaseFirestore) {

    fun listenToAppSettings(onUpdate: (JPhoneSettings) -> Unit) {
        db.collection("settings").document("general")
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    Log.e("JPhone", "Error listening to remote settings", error)
                    return@addSnapshotListener
                }

                if (snapshot != null && snapshot.exists()) {
                    val settings = snapshot.toObject(JPhoneSettings::class.java)
                    if (settings != null) {
                        onUpdate(settings)
                    }
                }
            }
    }
}
```

### Checking Maintenance Mode in Android:
```kotlin
if (settings.maintenanceMode) {
    if (userEnteredBypassKey != settings.maintenanceBypassKey) {
        // Display blocking maintenance UI
        showMaintenanceDialog(settings.maintenanceMessage)
        return
    }
}
```

---

## 3. Subscription Entitlement & Badge Logic in Android

In Android, query the user profile at `/users/{uid}`:

```kotlin
db.collection("users").document(currentUserId)
    .get()
    .addOnSuccessListener { doc ->
        val tier = doc.getString("subscriptionTier") ?: "free"
        val expiry = doc.getString("subscriptionExpiry")

        if (tier == "premium") {
            // Display blue PREMIUM badge in UI
            // Unlock ad-free dialer and HD recording
            enablePremiumFeatures()
        } else {
            // Display green FREE badge
            // Display AdMob banner and interstitials
            enableFreeFeaturesWithAds()
        }
    }
```
