import { useState } from 'react';
import { ShieldCheck, LogIn, AlertTriangle } from 'lucide-react';
import { signInWithGoogle, signOutAdmin, auth } from '../../services/firebase';

interface Props {
  state: 'loading' | 'signed_out' | 'denied';
}

export default function LoginScreen({ state }: Props) {
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleLogin = async () => {
    setBusy(true);
    setError(null);
    try {
      await signInWithGoogle();
    } catch (e: any) {
      setError(e?.message || 'Sign-in failed');
    } finally {
      setBusy(false);
    }
  };

  if (state === 'loading') {
    return (
      <div className="min-h-screen bg-slate-950 flex items-center justify-center">
        <div className="w-8 h-8 border-2 border-indigo-500 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex items-center justify-center p-4">
      <div className="w-full max-w-sm bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-5">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-indigo-600 flex items-center justify-center">
            <ShieldCheck className="w-5 h-5" />
          </div>
          <div>
            <div className="font-semibold">JPhone Admin</div>
            <div className="text-xs text-slate-400">Sirf authorized administrators</div>
          </div>
        </div>

        {state === 'denied' && (
          <div className="flex gap-2 text-sm text-amber-300 bg-amber-500/10 border border-amber-500/30 rounded-lg p-3">
            <AlertTriangle className="w-4 h-4 mt-0.5 shrink-0" />
            <div>
              <div>{auth?.currentUser?.email} admin nahi hai.</div>
              <div className="text-xs text-amber-200/70 mt-1">
                Firestore mein <span className="font-mono">admins/{auth?.currentUser?.uid}</span> document banayein, ya doosre account se login karein.
              </div>
              <button onClick={() => signOutAdmin()} className="underline text-xs mt-2">Sign out</button>
            </div>
          </div>
        )}

        {error && <div className="text-xs text-red-400 break-words">{error}</div>}

        <button
          onClick={handleLogin}
          disabled={busy}
          className="w-full flex items-center justify-center gap-2 bg-indigo-600 hover:bg-indigo-500 disabled:opacity-60 rounded-lg py-2.5 text-sm font-medium"
        >
          <LogIn className="w-4 h-4" />
          {busy ? 'Signing in...' : 'Google se Sign in karein'}
        </button>
      </div>
    </div>
  );
}
