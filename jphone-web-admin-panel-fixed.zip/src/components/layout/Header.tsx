import React, { useState } from 'react';
import { getStoredFirebaseConfig, auth, signOutAdmin } from '../../services/firebase';
import { FirebaseConfigModal } from '../ui/FirebaseConfigModal';
import { ConfirmDialog } from '../ui/ConfirmDialog';
import { 
  Shield, 
  Database, 
  Menu, 
  LogOut, 
  Sliders, 
  Bell, 
  AlertTriangle,
  UserCheck,
  CheckCircle2
} from 'lucide-react';

interface HeaderProps {
  onOpenMobileNav: () => void;
  onNavigate: (page: string) => void;
  currentPage: string;
}

export const Header: React.FC<HeaderProps> = ({ onOpenMobileNav, onNavigate, currentPage }) => {
  const [configModalOpen, setConfigModalOpen] = useState(false);
  const [confirmSignOut, setConfirmSignOut] = useState(false);
  const config = getStoredFirebaseConfig();
  const currentUser = auth?.currentUser;

  // Active admin profile display (fallback to verified provisioned email)
  const adminEmail = currentUser?.email || 'attamuhammad6008@gmail.com';
  const isSuperAdmin = true;

  const handleSignOut = async () => {
    await signOutAdmin();
    setConfirmSignOut(false);
    window.location.reload();
  };

  return (
    <>
      <header className="h-16 border-b border-slate-800/80 bg-slate-900/60 backdrop-blur-md sticky top-0 z-30 px-4 md:px-8 flex items-center justify-between">
        {/* Left: Mobile hamburger & Page Breadcrumb */}
        <div className="flex items-center gap-3">
          <button
            onClick={onOpenMobileNav}
            className="md:hidden p-2 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
            aria-label="Open mobile navigation"
          >
            <Menu className="w-5 h-5" />
          </button>

          <div className="flex items-center gap-2">
            <span className="text-sm font-semibold text-slate-400 hidden sm:inline">JPhone Admin</span>
            <span className="text-slate-600 hidden sm:inline">/</span>
            <span className="text-sm font-bold text-white capitalize">
              {currentPage.replace('-', ' ')}
            </span>
          </div>
        </div>

        {/* Right: Environment status, Diagnostic shortcut, Admin profile, Sign out */}
        <div className="flex items-center gap-3">
          {/* Mode Pill: Live Firebase vs Preview Sandbox */}
          <button
            onClick={() => setConfigModalOpen(true)}
            className={`flex items-center gap-2 px-3 py-1.5 rounded-full text-xs font-mono border transition-all ${
              config
                ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30 hover:bg-emerald-500/20'
                : 'bg-indigo-500/10 text-indigo-400 border-indigo-500/30 hover:bg-indigo-500/20'
            }`}
            title="Click to view or edit Firebase configuration"
          >
            <span className={`w-2 h-2 rounded-full ${config ? 'bg-emerald-400 animate-pulse' : 'bg-indigo-400'}`} />
            <span className="font-semibold">{config ? `LIVE: ${config.projectId}` : 'SANDBOX PREVIEW'}</span>
            <Sliders className="w-3.5 h-3.5 text-slate-400" />
          </button>

          {/* Quick Diagnostics Badge */}
          <button
            onClick={() => onNavigate('diagnostics')}
            className="hidden sm:flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-medium text-amber-300 bg-amber-500/10 border border-amber-500/30 hover:bg-amber-500/20 transition-colors"
            title="Investigate CONFIGURATION_NOT_FOUND error"
          >
            <AlertTriangle className="w-3.5 h-3.5 text-amber-400" />
            <span>Diagnostics</span>
          </button>

          {/* Admin Avatar & Role */}
          <div className="flex items-center gap-2.5 pl-2 border-l border-slate-800">
            <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-indigo-600 to-violet-500 flex items-center justify-center font-bold text-xs text-white shadow-md">
              {adminEmail.charAt(0).toUpperCase()}
            </div>
            <div className="hidden lg:block text-left">
              <div className="text-xs font-semibold text-slate-200 truncate max-w-[170px]" title={adminEmail}>
                {adminEmail}
              </div>
              <div className="text-[10px] text-indigo-400 font-mono flex items-center gap-1">
                <Shield className="w-2.5 h-2.5" />
                <span>SUPER ADMIN</span>
              </div>
            </div>

            <button
              onClick={() => setConfirmSignOut(true)}
              className="p-2 rounded-lg text-slate-400 hover:text-rose-400 hover:bg-rose-500/10 transition-colors ml-1"
              title="Sign out administrator"
            >
              <LogOut className="w-4 h-4" />
            </button>
          </div>
        </div>
      </header>

      <FirebaseConfigModal 
        isOpen={configModalOpen} 
        onClose={() => setConfigModalOpen(false)} 
      />

      <ConfirmDialog
        isOpen={confirmSignOut}
        onClose={() => setConfirmSignOut(false)}
        onConfirm={handleSignOut}
        title="Sign Out Administrator"
        message="Are you sure you want to end your administrative session? You will need to re-authenticate with your verified administrator credentials."
        confirmLabel="Sign Out"
        isDestructive={true}
      />
    </>
  );
};
