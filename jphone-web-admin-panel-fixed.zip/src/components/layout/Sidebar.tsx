import React from 'react';
import { 
  LayoutDashboard, 
  Users, 
  CreditCard, 
  Settings, 
  MessageSquare, 
  Megaphone, 
  Bell, 
  Smartphone, 
  Activity, 
  FileText, 
  BookOpen,
  PhoneCall,
  X
} from 'lucide-react';

interface SidebarProps {
  currentPage: string;
  onNavigate: (page: string) => void;
  isMobileOpen: boolean;
  onCloseMobile: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  currentPage,
  onNavigate,
  isMobileOpen,
  onCloseMobile
}) => {
  const navItems = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'users', label: 'User Management', icon: Users, badge: 'Badges' },
    { id: 'plans', label: 'Plans & Premium', icon: CreditCard },
    { id: 'settings', label: 'App Settings', icon: Settings },
    { id: 'whatsapp', label: 'WhatsApp Support', icon: MessageSquare },
    { id: 'ads', label: 'Ads Management', icon: Megaphone },
    { id: 'notifications', label: 'Push Notifications', icon: Bell },
    { id: 'app-update', label: 'App Update Manager', icon: Smartphone },
    { id: 'diagnostics', label: 'Diagnostics & OTP', icon: Activity, highlight: true },
    { id: 'audit-logs', label: 'Audit Logs', icon: FileText },
    { id: 'setup-guide', label: 'Hosting & Setup', icon: BookOpen }
  ];

  const handleSelect = (id: string) => {
    onNavigate(id);
    onCloseMobile();
  };

  const content = (
    <div className="flex flex-col h-full bg-slate-900 border-r border-slate-800">
      {/* Brand Header */}
      <div className="p-5 border-b border-slate-800 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-indigo-500 to-violet-600 flex items-center justify-center text-white shadow-lg shadow-indigo-900/30">
            <PhoneCall className="w-5 h-5" />
          </div>
          <div>
            <div className="font-extrabold text-base tracking-tight text-white flex items-center gap-1.5">
              <span>JPhone</span>
              <span className="text-[10px] font-mono font-bold uppercase tracking-wider px-1.5 py-0.5 rounded bg-indigo-500/20 text-indigo-400 border border-indigo-500/30">
                Admin
              </span>
            </div>
            <div className="text-[11px] text-slate-400 font-medium">
              Android Ecosystem Suite
            </div>
          </div>
        </div>

        {/* Mobile close button */}
        <button
          onClick={onCloseMobile}
          className="md:hidden p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800"
          aria-label="Close menu"
        >
          <X className="w-5 h-5" />
        </button>
      </div>

      {/* Nav List */}
      <nav className="flex-1 px-3 py-4 space-y-1 overflow-y-auto">
        <div className="px-3 pb-2 text-[10px] font-bold uppercase tracking-wider text-slate-500">
          Core Operations
        </div>
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = currentPage === item.id;
          return (
            <button
              key={item.id}
              onClick={() => handleSelect(item.id)}
              className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-xs font-semibold transition-all group ${
                isActive
                  ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-900/30 font-bold'
                  : 'text-slate-300 hover:text-white hover:bg-slate-800/80'
              }`}
            >
              <div className="flex items-center gap-3">
                <Icon className={`w-4 h-4 transition-colors ${
                  isActive ? 'text-white' : item.highlight ? 'text-amber-400' : 'text-slate-400 group-hover:text-indigo-400'
                }`} />
                <span>{item.label}</span>
              </div>

              {item.highlight && !isActive && (
                <span className="w-2 h-2 rounded-full bg-amber-400 animate-ping" />
              )}
              {item.badge && !isActive && (
                <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-slate-800 text-slate-400 border border-slate-700">
                  {item.badge}
                </span>
              )}
            </button>
          );
        })}
      </nav>

      {/* Bottom Android Sync Card */}
      <div className="p-3.5 border-t border-slate-800 m-3 bg-slate-950/60 rounded-xl border border-slate-800/80">
        <div className="flex items-center justify-between text-xs text-slate-300 font-semibold mb-1">
          <span>Android App Client</span>
          <span className="text-[10px] text-emerald-400 font-mono flex items-center gap-1">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
            Sync Ready
          </span>
        </div>
        <div className="text-[11px] text-slate-500 font-mono">
          Package: com.aistudio.jphone.qkzvtb
        </div>
        <div className="text-[10px] text-slate-400 mt-2 flex items-center justify-between">
          <span>Target Platform:</span>
          <span className="text-slate-200 font-semibold">Android 14+</span>
        </div>
      </div>
    </div>
  );

  return (
    <>
      {/* Desktop Persistent Sidebar */}
      <aside className="hidden md:block w-64 shrink-0 h-screen sticky top-0 z-40">
        {content}
      </aside>

      {/* Mobile Drawer */}
      {isMobileOpen && (
        <div className="fixed inset-0 z-50 md:hidden flex">
          <div
            className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm"
            onClick={onCloseMobile}
          />
          <div className="relative w-72 max-w-[85vw] h-full z-10">
            {content}
          </div>
        </div>
      )}
    </>
  );
};
