import React, { useState } from 'react';
import { Modal } from '../ui/Modal';
import { JPhoneUser } from '../../types';
import { AlertTriangle } from 'lucide-react';

interface SuspendModalProps {
  isOpen: boolean;
  user: JPhoneUser | null;
  onClose: () => void;
  onConfirm: (reason: string) => Promise<void>;
}

export const SuspendModal: React.FC<SuspendModalProps> = ({
  isOpen,
  user,
  onClose,
  onConfirm
}) => {
  const [reason, setReason] = useState('');
  const [loading, setLoading] = useState(false);

  if (!user) return null;

  const isSuspending = !user.isSuspended;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (isSuspending && !reason.trim()) {
      alert('Please specify a reason for this suspension.');
      return;
    }
    setLoading(true);
    try {
      await onConfirm(reason);
      setReason('');
      onClose();
    } finally {
      setLoading(false);
    }
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title={isSuspending ? 'Suspend User Account' : 'Reactivate User Account'}
      subtitle={`Target User: ${user.displayName || user.email || user.id}`}
      maxWidth="md"
    >
      <form onSubmit={handleSubmit} className="space-y-4">
        <div className={`p-3 rounded-xl border text-xs flex items-start gap-3 ${
          isSuspending 
            ? 'bg-rose-500/10 text-rose-300 border-rose-500/30' 
            : 'bg-emerald-500/10 text-emerald-300 border-emerald-500/30'
        }`}>
          <AlertTriangle className="w-5 h-5 shrink-0 mt-0.5" />
          <div>
            {isSuspending ? (
              <span>
                Suspending this user will immediately revoke API session tokens and restrict dialer and cloud backup features in the JPhone Android application.
              </span>
            ) : (
              <span>
                Reactivating this account will restore normal access to JPhone Android client features and synchronize user permissions.
              </span>
            )}
          </div>
        </div>

        {isSuspending && (
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">
              Suspension Reason <span className="text-rose-400">*</span>
            </label>
            <textarea
              required
              rows={3}
              value={reason}
              onChange={(e) => setReason(e.target.value)}
              placeholder="e.g. Terms violation, reported robocall spam, fraudulent payment activity..."
              className="w-full bg-slate-950 border border-slate-800 rounded-lg p-3 text-xs text-white placeholder-slate-600 focus:outline-none focus:border-indigo-500"
            />
            <p className="text-[11px] text-slate-500 mt-1">This reason is recorded immutably in the administrative audit logs.</p>
          </div>
        )}

        <div className="pt-3 border-t border-slate-800 flex items-center justify-end gap-3">
          <button
            type="button"
            onClick={onClose}
            disabled={loading}
            className="px-4 py-2 text-xs font-medium text-slate-400 hover:text-white"
          >
            Cancel
          </button>
          <button
            type="submit"
            disabled={loading}
            className={`px-4 py-2 text-xs font-semibold text-white rounded-lg shadow-lg transition-colors ${
              isSuspending
                ? 'bg-rose-600 hover:bg-rose-500 shadow-rose-900/30'
                : 'bg-emerald-600 hover:bg-emerald-500 shadow-emerald-900/30'
            }`}
          >
            {loading ? 'Processing...' : isSuspending ? 'Confirm Account Suspension' : 'Reactivate Account'}
          </button>
        </div>
      </form>
    </Modal>
  );
};
