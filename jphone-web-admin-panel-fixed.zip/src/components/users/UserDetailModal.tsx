import React, { useState } from 'react';
import { Modal } from '../ui/Modal';
import { TierBadge, Badge } from '../ui/Badge';
import { JPhoneUser } from '../../types';
import { 
  User, 
  Mail, 
  Phone, 
  Calendar, 
  Clock, 
  ShieldCheck, 
  ShieldAlert, 
  FileText, 
  CheckCircle2, 
  XCircle,
  Crown,
  AlertTriangle,
  Save
} from 'lucide-react';

interface UserDetailModalProps {
  isOpen: boolean;
  user: JPhoneUser | null;
  onClose: () => void;
  onOpenSuspend: (user: JPhoneUser) => void;
  onOpenGrantPremium: (user: JPhoneUser) => void;
  onSaveNotes: (userId: string, notes: string) => Promise<void>;
}

export const UserDetailModal: React.FC<UserDetailModalProps> = ({
  isOpen,
  user,
  onClose,
  onOpenSuspend,
  onOpenGrantPremium,
  onSaveNotes
}) => {
  const [notes, setNotes] = useState(user?.adminNotes || '');
  const [isSavingNotes, setIsSavingNotes] = useState(false);
  const [saveSuccess, setSaveSuccess] = useState(false);

  // Sync state when user prop changes
  React.useEffect(() => {
    if (user) {
      setNotes(user.adminNotes || '');
      setSaveSuccess(false);
    }
  }, [user]);

  if (!user) return null;

  const handleSaveNotesClick = async () => {
    setIsSavingNotes(true);
    setSaveSuccess(false);
    try {
      await onSaveNotes(user.id, notes);
      setSaveSuccess(true);
      setTimeout(() => setSaveSuccess(false), 2500);
    } finally {
      setIsSavingNotes(false);
    }
  };

  const isPremium = user.subscriptionTier === 'premium';

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title="User Account Details"
      subtitle={`UID: ${user.id}`}
      maxWidth="xl"
    >
      <div className="space-y-6">
        {/* Top Header Card with Badges */}
        <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-xl bg-indigo-500/10 border border-indigo-500/20 flex items-center justify-center text-indigo-400 font-bold text-lg">
              {user.displayName ? user.displayName.charAt(0).toUpperCase() : <User className="w-6 h-6" />}
            </div>
            <div>
              <h4 className="text-base font-bold text-white flex items-center gap-2">
                <span>{user.displayName || 'Unnamed User'}</span>
                {user.isSuspended && (
                  <Badge variant="danger" size="sm">SUSPENDED</Badge>
                )}
              </h4>
              <p className="text-xs text-slate-400 font-mono mt-0.5">{user.id}</p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <TierBadge tier={user.subscriptionTier} size="md" />
            <span className={`text-xs px-2.5 py-1 rounded font-semibold border ${
              user.isSuspended 
                ? 'bg-rose-500/10 text-rose-400 border-rose-500/30' 
                : 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30'
            }`}>
              {user.isSuspended ? 'Account Suspended' : 'Account Active'}
            </span>
          </div>
        </div>

        {/* Suspension Alert if applicable */}
        {user.isSuspended && (
          <div className="p-3 bg-rose-500/10 border border-rose-500/30 rounded-xl text-xs text-rose-300 flex items-start gap-3">
            <ShieldAlert className="w-5 h-5 shrink-0 mt-0.5 text-rose-400" />
            <div>
              <span className="font-semibold text-rose-200">Suspension Reason:</span> {user.suspendedReason || 'Administrative enforcement action'}
            </div>
          </div>
        )}

        {/* Verification & Contact Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {/* Email Verification Box */}
          <div className="p-4 bg-slate-950/60 rounded-xl border border-slate-800">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-semibold text-slate-400 flex items-center gap-1.5">
                <Mail className="w-3.5 h-3.5 text-slate-400" /> Email Verification
              </span>
              {user.emailVerified ? (
                <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/30">
                  <CheckCircle2 className="w-3 h-3" /> Verified
                </span>
              ) : (
                <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-slate-400 bg-slate-800 px-2 py-0.5 rounded border border-slate-700">
                  <XCircle className="w-3 h-3" /> Unverified
                </span>
              )}
            </div>
            <div className="text-sm font-medium text-white truncate" title={user.email || 'No email registered'}>
              {user.email || 'No email registered'}
            </div>
          </div>

          {/* Phone Verification Box */}
          <div className="p-4 bg-slate-950/60 rounded-xl border border-slate-800">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-semibold text-slate-400 flex items-center gap-1.5">
                <Phone className="w-3.5 h-3.5 text-slate-400" /> Phone OTP Verification
              </span>
              {user.phoneVerified ? (
                <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/30">
                  <CheckCircle2 className="w-3 h-3" /> OTP Verified
                </span>
              ) : (
                <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-amber-400 bg-amber-500/10 px-2 py-0.5 rounded border border-amber-500/30">
                  <XCircle className="w-3 h-3" /> Pending OTP
                </span>
              )}
            </div>
            <div className="text-sm font-medium font-mono text-white">
              {user.phoneNumber || 'No phone registered'}
            </div>
          </div>
        </div>

        {/* Subscription & Timestamps */}
        <div className="p-4 bg-slate-950/60 rounded-xl border border-slate-800 space-y-3">
          <div className="text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center gap-2">
            <Crown className="w-4 h-4 text-amber-400" /> Subscription & Lifecycle
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
            <div>
              <span className="text-slate-500 block">Current Entitlement</span>
              <div className="mt-1">
                <TierBadge tier={user.subscriptionTier} size="sm" />
              </div>
            </div>
            <div>
              <span className="text-slate-500 block">Premium Expiration</span>
              <span className="text-slate-200 font-mono font-medium block mt-1">
                {user.subscriptionExpiry 
                  ? new Date(user.subscriptionExpiry).toLocaleDateString()
                  : isPremium ? 'Lifetime Supporter' : 'N/A (Free Tier)'}
              </span>
            </div>
            <div>
              <span className="text-slate-500 block">Account Created</span>
              <span className="text-slate-200 font-mono font-medium block mt-1">
                {new Date(user.createdAt).toLocaleDateString()}
              </span>
            </div>
          </div>
        </div>

        {/* Administrative Notes Editor */}
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <label className="text-xs font-semibold text-slate-300 flex items-center gap-1.5">
              <FileText className="w-3.5 h-3.5 text-indigo-400" /> Confidential Administrator Notes
            </label>
            {saveSuccess && (
              <span className="text-xs text-emerald-400 flex items-center gap-1 font-medium">
                <CheckCircle2 className="w-3.5 h-3.5" /> Notes Saved
              </span>
            )}
          </div>
          <textarea
            rows={3}
            value={notes}
            onChange={(e) => setNotes(e.target.value)}
            placeholder="Add internal notes regarding customer disputes, VIP requests, or verification history..."
            className="w-full bg-slate-950 border border-slate-800 rounded-lg p-3 text-xs text-white placeholder-slate-600 focus:outline-none focus:border-indigo-500"
          />
          <div className="flex justify-end">
            <button
              type="button"
              onClick={handleSaveNotesClick}
              disabled={isSavingNotes || notes === (user.adminNotes || '')}
              className="px-3 py-1.5 text-xs font-medium text-white bg-slate-800 hover:bg-slate-700 disabled:opacity-50 disabled:hover:bg-slate-800 rounded-lg flex items-center gap-1.5 transition-colors"
            >
              <Save className="w-3.5 h-3.5" />
              {isSavingNotes ? 'Saving...' : 'Save Notes'}
            </button>
          </div>
        </div>

        {/* Action Controls */}
        <div className="pt-4 border-t border-slate-800 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => {
                onClose();
                onOpenGrantPremium(user);
              }}
              className={`px-3.5 py-2 text-xs font-semibold rounded-lg flex items-center gap-2 transition-all ${
                isPremium
                  ? 'bg-amber-500/10 hover:bg-amber-500/20 text-amber-300 border border-amber-500/30'
                  : 'bg-blue-600 hover:bg-blue-500 text-white shadow-lg shadow-blue-900/30'
              }`}
            >
              <Crown className="w-3.5 h-3.5" />
              {isPremium ? 'Revoke Premium' : 'Grant Premium Access'}
            </button>

            <button
              type="button"
              onClick={() => {
                onClose();
                onOpenSuspend(user);
              }}
              className={`px-3.5 py-2 text-xs font-semibold rounded-lg flex items-center gap-2 transition-all ${
                user.isSuspended
                  ? 'bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                  : 'bg-rose-500/10 hover:bg-rose-500/20 text-rose-300 border border-rose-500/30'
              }`}
            >
              {user.isSuspended ? (
                <>
                  <ShieldCheck className="w-3.5 h-3.5" />
                  Reactivate Account
                </>
              ) : (
                <>
                  <ShieldAlert className="w-3.5 h-3.5" />
                  Suspend Account
                </>
              )}
            </button>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 text-xs font-medium text-slate-400 hover:text-white"
          >
            Close
          </button>
        </div>
      </div>
    </Modal>
  );
};
