import React, { useState } from 'react';
import { Modal } from '../ui/Modal';
import { JPhoneUser } from '../../types';
import { Crown, Sparkles, AlertCircle } from 'lucide-react';

interface GrantPremiumModalProps {
  isOpen: boolean;
  user: JPhoneUser | null;
  onClose: () => void;
  onConfirm: (tier: 'premium' | 'free', durationDays: number, reason: string) => Promise<void>;
}

export const GrantPremiumModal: React.FC<GrantPremiumModalProps> = ({
  isOpen,
  user,
  onClose,
  onConfirm
}) => {
  const [duration, setDuration] = useState<number>(30);
  const [reason, setReason] = useState('Customer Support Resolution / Loyalty Grant');
  const [loading, setLoading] = useState(false);

  if (!user) return null;

  const isAlreadyPremium = user.subscriptionTier === 'premium';

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      if (isAlreadyPremium) {
        // Revoke back to free
        await onConfirm('free', 0, reason || 'Admin revoked premium access');
      } else {
        await onConfirm('premium', duration, reason || 'Complimentary premium grant');
      }
      onClose();
    } finally {
      setLoading(false);
    }
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title={isAlreadyPremium ? 'Revoke Premium Subscription' : 'Grant Complimentary Premium Access'}
      subtitle={`User: ${user.displayName || user.email || user.id}`}
      maxWidth="md"
    >
      <form onSubmit={handleSubmit} className="space-y-4">
        {isAlreadyPremium ? (
          <div className="p-3 bg-amber-500/10 border border-amber-500/30 rounded-xl text-xs text-amber-300 flex items-start gap-3">
            <AlertCircle className="w-5 h-5 shrink-0 mt-0.5 text-amber-400" />
            <div>
              <span className="font-semibold text-white">Revoking Premium:</span> This user will immediately revert to the green <span className="badge-free">FREE</span> tier in their Android app and lose access to premium caller ID and ad-free dialer features.
            </div>
          </div>
        ) : (
          <div className="p-3 bg-blue-500/10 border border-blue-500/30 rounded-xl text-xs text-blue-300 flex items-start gap-3">
            <Crown className="w-5 h-5 shrink-0 mt-0.5 text-blue-400" />
            <div>
              <span className="font-semibold text-white">Authoritative Entitlement:</span> This action assigns the blue <span className="badge-premium">PREMIUM</span> badge directly in the database. The JPhone Android client will synchronize this entitlement on next boot.
            </div>
          </div>
        )}

        {!isAlreadyPremium && (
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1.5">
              Duration Period
            </label>
            <div className="grid grid-cols-3 gap-2">
              {[
                { label: '30 Days', days: 30 },
                { label: '90 Days', days: 90 },
                { label: '1 Year', days: 365 },
                { label: 'Founder Pass', days: 3650 }
              ].map((item) => (
                <button
                  key={item.days}
                  type="button"
                  onClick={() => setDuration(item.days)}
                  className={`py-2 px-3 text-xs font-semibold rounded-lg border transition-all ${
                    duration === item.days
                      ? 'bg-blue-600 text-white border-blue-500 shadow-md shadow-blue-900/30'
                      : 'bg-slate-950 text-slate-300 border-slate-800 hover:border-slate-700'
                  }`}
                >
                  {item.label}
                </button>
              ))}
            </div>
          </div>
        )}

        <div>
          <label className="block text-xs font-semibold text-slate-300 mb-1">
            Reason for Administrative Action <span className="text-rose-400">*</span>
          </label>
          <input
            type="text"
            required
            value={reason}
            onChange={(e) => setReason(e.target.value)}
            placeholder="e.g. Beta tester grant, VIP customer retention, contest winner..."
            className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white placeholder-slate-600 focus:outline-none focus:border-indigo-500"
          />
          <p className="text-[11px] text-slate-500 mt-1">Logged with your administrator email and timestamp for compliance auditing.</p>
        </div>

        <div className="pt-3 border-t border-slate-800 flex items-center justify-end gap-3">
          <button
            type="button"
            onClick={onClose}
            disabled={loading}
            className="px-4 py-2 text-xs font-medium text-slate-400 hover:text-white"
          >
            Cancel
          </button>
          <button
            type="submit"
            disabled={loading}
            className={`px-4 py-2 text-xs font-semibold text-white rounded-lg shadow-lg transition-colors ${
              isAlreadyPremium
                ? 'bg-amber-600 hover:bg-amber-500 shadow-amber-900/30'
                : 'bg-blue-600 hover:bg-blue-500 shadow-blue-900/30'
            }`}
          >
            {loading ? 'Processing...' : isAlreadyPremium ? 'Revoke to FREE Tier' : 'Grant PREMIUM Access'}
          </button>
        </div>
      </form>
    </Modal>
  );
};
