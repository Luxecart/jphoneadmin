import React, { useState, useEffect } from 'react';
import { Modal } from '../ui/Modal';
import { Plan } from '../../types';

interface PlanEditorModalProps {
  isOpen: boolean;
  plan: Plan | null;
  onClose: () => void;
  onSave: (plan: Plan, isNew: boolean) => Promise<void>;
}

export const PlanEditorModal: React.FC<PlanEditorModalProps> = ({
  isOpen,
  plan,
  onClose,
  onSave
}) => {
  const [name, setName] = useState('');
  const [code, setCode] = useState('');
  const [price, setPrice] = useState<number>(4.99);
  const [currency, setCurrency] = useState('USD');
  const [durationDays, setDurationDays] = useState<number>(30);
  const [description, setDescription] = useState('');
  const [featuresText, setFeaturesText] = useState('');
  const [isActive, setIsActive] = useState(true);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (plan) {
      setName(plan.name);
      setCode(plan.code);
      setPrice(plan.price);
      setCurrency(plan.currency);
      setDurationDays(plan.durationDays);
      setDescription(plan.description);
      setFeaturesText(plan.features.join('\n'));
      setIsActive(plan.isActive);
    } else {
      setName('');
      setCode('');
      setPrice(9.99);
      setCurrency('USD');
      setDurationDays(30);
      setDescription('');
      setFeaturesText('Zero Advertisements\nHD Voice Quality\nAutomatic Call Recording\nPriority WhatsApp Support');
      setIsActive(true);
    }
  }, [plan, isOpen]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !code.trim()) {
      alert('Plan Name and SKU code are required.');
      return;
    }

    const features = featuresText
      .split('\n')
      .map(f => f.trim())
      .filter(f => f.length > 0);

    const planData: Plan = {
      id: plan ? plan.id : `plan_${code.toLowerCase().replace(/[^a-z0-9_]/g, '_')}`,
      name: name.trim(),
      code: code.trim().toLowerCase(),
      price: Number(price),
      currency: currency.trim().toUpperCase(),
      durationDays: Number(durationDays),
      description: description.trim(),
      features,
      isActive,
      updatedAt: new Date().toISOString(),
      updatedBy: 'admin'
    };

    setLoading(true);
    try {
      await onSave(planData, !plan);
      onClose();
    } finally {
      setLoading(false);
    }
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title={plan ? `Edit Plan: ${plan.name}` : 'Create Subscription Plan'}
      subtitle="Configure pricing, billing cycle duration, and user entitlements"
      maxWidth="lg"
    >
      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">
              Plan Display Name <span className="text-rose-400">*</span>
            </label>
            <input
              type="text"
              required
              value={name}
              onChange={(e) => {
                setName(e.target.value);
                if (!plan && !code) {
                  setCode(e.target.value.toLowerCase().replace(/[^a-z0-9_]/g, '_'));
                }
              }}
              placeholder="e.g. JPhone Pro Monthly"
              className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white placeholder-slate-600 focus:outline-none focus:border-indigo-500"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">
              Product SKU / Code <span className="text-rose-400">*</span>
            </label>
            <input
              type="text"
              required
              value={code}
              onChange={(e) => setCode(e.target.value)}
              placeholder="e.g. jphone_pro_monthly"
              className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs font-mono text-white placeholder-slate-600 focus:outline-none focus:border-indigo-500"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">
              Price ({currency}) <span className="text-rose-400">*</span>
            </label>
            <input
              type="number"
              step="0.01"
              required
              min="0"
              value={price}
              onChange={(e) => setPrice(parseFloat(e.target.value) || 0)}
              className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white placeholder-slate-600 focus:outline-none focus:border-indigo-500 font-mono"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">
              Duration (Days) <span className="text-rose-400">*</span>
            </label>
            <input
              type="number"
              required
              min="1"
              value={durationDays}
              onChange={(e) => setDurationDays(parseInt(e.target.value) || 30)}
              className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white placeholder-slate-600 focus:outline-none focus:border-indigo-500 font-mono"
            />
            <p className="text-[11px] text-slate-500 mt-1">30 = 1 month, 365 = 1 year, 3650 = Lifetime</p>
          </div>
        </div>

        <div>
          <label className="block text-xs font-semibold text-slate-300 mb-1">
            Short Description
          </label>
          <input
            type="text"
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            placeholder="e.g. Ad-free dialer with caller ID and unlimited call recordings"
            className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white placeholder-slate-600 focus:outline-none focus:border-indigo-500"
          />
        </div>

        <div>
          <label className="block text-xs font-semibold text-slate-300 mb-1">
            Included Features (One per line)
          </label>
          <textarea
            rows={4}
            value={featuresText}
            onChange={(e) => setFeaturesText(e.target.value)}
            placeholder="Zero Advertisements&#10;HD Call Recording&#10;Spam Protection"
            className="w-full bg-slate-950 border border-slate-800 rounded-lg p-3 text-xs text-white placeholder-slate-600 focus:outline-none focus:border-indigo-500 font-mono"
          />
        </div>

        <div className="flex items-center gap-3 p-3 bg-slate-950 rounded-xl border border-slate-800">
          <input
            type="checkbox"
            id="isActiveCheck"
            checked={isActive}
            onChange={(e) => setIsActive(e.target.checked)}
            className="w-4 h-4 text-indigo-600 rounded bg-slate-900 border-slate-700 focus:ring-indigo-500"
          />
          <label htmlFor="isActiveCheck" className="text-xs text-slate-300 cursor-pointer">
            <span className="font-semibold text-white">Enable Plan for Subscription Checkout</span>
            <span className="block text-slate-400 text-[11px]">When disabled, new purchases will be blocked in the JPhone Android application.</span>
          </label>
        </div>

        <div className="pt-3 border-t border-slate-800 flex items-center justify-end gap-3">
          <button
            type="button"
            onClick={onClose}
            disabled={loading}
            className="px-4 py-2 text-xs font-medium text-slate-400 hover:text-white"
          >
            Cancel
          </button>
          <button
            type="submit"
            disabled={loading}
            className="px-4 py-2 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-500 rounded-lg shadow-lg shadow-indigo-900/30 transition-colors"
          >
            {loading ? 'Saving Plan...' : plan ? 'Update Plan' : 'Create Plan'}
          </button>
        </div>
      </form>
    </Modal>
  );
};
