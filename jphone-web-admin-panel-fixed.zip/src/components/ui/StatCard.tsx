import React from 'react';

interface StatCardProps {
  title: string;
  value: string | number;
  subtitle?: string;
  icon: React.ReactNode;
  trend?: {
    value: string;
    positive: boolean;
  };
  reliability?: 'verified' | 'pending' | 'preview';
  onClick?: () => void;
}

export const StatCard: React.FC<StatCardProps> = ({
  title,
  value,
  subtitle,
  icon,
  trend,
  reliability,
  onClick
}) => {
  return (
    <div 
      onClick={onClick}
      className={`glass-panel p-5 transition-all duration-200 hover:border-slate-700 hover:shadow-2xl ${onClick ? 'cursor-pointer' : ''}`}
    >
      <div className="flex items-start justify-between">
        <div className="p-2.5 rounded-lg bg-slate-800/80 border border-slate-700 text-indigo-400">
          {icon}
        </div>
        {reliability && (
          <span className={`text-[10px] font-mono uppercase px-2 py-0.5 rounded border ${
            reliability === 'verified'
              ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30'
              : reliability === 'pending'
              ? 'bg-amber-500/10 text-amber-400 border-amber-500/30'
              : 'bg-indigo-500/10 text-indigo-400 border-indigo-500/30'
          }`}>
            {reliability === 'verified' ? 'Authoritative' : reliability === 'pending' ? 'Pending Provider' : 'Demo Sandbox'}
          </span>
        )}
      </div>

      <div className="mt-4">
        <div className="text-2xl font-bold tracking-tight text-white font-mono">
          {value}
        </div>
        <div className="text-xs font-medium text-slate-400 mt-1">
          {title}
        </div>
      </div>

      {(subtitle || trend) && (
        <div className="mt-3 pt-3 border-t border-slate-800/80 flex items-center justify-between text-xs text-slate-400">
          {subtitle && <span>{subtitle}</span>}
          {trend && (
            <span className={`font-medium ${trend.positive ? 'text-emerald-400' : 'text-rose-400'}`}>
              {trend.positive ? '+' : ''}{trend.value}
            </span>
          )}
        </div>
      )}
    </div>
  );
};
