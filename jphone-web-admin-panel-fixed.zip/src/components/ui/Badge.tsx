import React from 'react';
import { SubscriptionTier } from '../../types';

interface BadgeProps {
  children?: React.ReactNode;
  variant?: 'free' | 'premium' | 'success' | 'danger' | 'warning' | 'info' | 'neutral';
  size?: 'sm' | 'md';
  className?: string;
}

export const Badge: React.FC<BadgeProps> = ({ 
  children, 
  variant = 'neutral', 
  size = 'md',
  className = '' 
}) => {
  const sizeClasses = size === 'sm' ? 'px-2 py-0.5 text-[11px]' : 'px-2.5 py-1 text-xs';

  const variantClasses = {
    free: 'badge-free',
    premium: 'badge-premium',
    success: 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30',
    danger: 'bg-rose-500/10 text-rose-400 border border-rose-500/30',
    warning: 'bg-amber-500/10 text-amber-400 border border-amber-500/30',
    info: 'bg-sky-500/10 text-sky-400 border border-sky-500/30',
    neutral: 'bg-slate-800 text-slate-300 border border-slate-700'
  }[variant];

  return (
    <span className={`inline-flex items-center gap-1 font-semibold rounded-md ${sizeClasses} ${variantClasses} ${className}`}>
      {children}
    </span>
  );
};

export const TierBadge: React.FC<{ tier: SubscriptionTier; size?: 'sm' | 'md' }> = ({ tier, size = 'md' }) => {
  if (tier === 'premium') {
    return (
      <span className={`badge-premium ${size === 'sm' ? 'text-[10px] px-2 py-0.5' : 'text-xs px-2.5 py-1'}`}>
        <span className="w-1.5 h-1.5 rounded-full bg-blue-400 animate-pulse"></span>
        PREMIUM
      </span>
    );
  }

  return (
    <span className={`badge-free ${size === 'sm' ? 'text-[10px] px-2 py-0.5' : 'text-xs px-2.5 py-1'}`}>
      FREE
    </span>
  );
};
