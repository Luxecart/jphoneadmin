import React, { useState } from 'react';
import { PushNotification } from '../types';
import { ConfirmDialog } from '../components/ui/ConfirmDialog';
import { 
  Bell, 
  Send, 
  Smartphone, 
  Check, 
  Clock, 
  Users, 
  ExternalLink,
  ShieldCheck,
  AlertCircle
} from 'lucide-react';

interface NotificationsPageProps {
  notifications: PushNotification[];
  onSendNotification: (notif: Omit<PushNotification, 'id' | 'sentAt' | 'sentByAdminId' | 'status' | 'deliveryCount'>) => Promise<PushNotification>;
}

export const NotificationsPage: React.FC<NotificationsPageProps> = ({
  notifications,
  onSendNotification
}) => {
  const [title, setTitle] = useState('');
  const [body, setBody] = useState('');
  const [imageUrl, setImageUrl] = useState('');
  const [targetAudience, setTargetAudience] = useState<'all' | 'free_users' | 'premium_users' | 'topic_announcements'>('all');
  const [deepLink, setDeepLink] = useState('jphone://premium');

  const [isConfirmOpen, setIsConfirmOpen] = useState(false);
  const [isSending, setIsSending] = useState(false);
  const [successMessage, setSuccessMessage] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !body.trim()) {
      alert('Notification title and message body are required.');
      return;
    }
    setIsConfirmOpen(true);
  };

  const handleConfirmSend = async () => {
    setIsSending(true);
    try {
      await onSendNotification({
        title: title.trim(),
        body: body.trim(),
        imageUrl: imageUrl.trim() || undefined,
        targetAudience,
        deepLink: deepLink.trim() || undefined
      });
      setTitle('');
      setBody('');
      setImageUrl('');
      setIsConfirmOpen(false);
      setSuccessMessage(true);
      setTimeout(() => setSuccessMessage(false), 3000);
    } finally {
      setIsSending(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-white flex items-center gap-2">
            <Bell className="w-5 h-5 text-indigo-400" />
            <span>Push Notifications (Firebase Cloud Messaging)</span>
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Dispatch authorized push broadcasts with audience segmentation and deep-link routing.
          </p>
        </div>

        {successMessage && (
          <span className="text-xs font-semibold text-emerald-400 bg-emerald-500/10 px-3 py-1.5 rounded-lg border border-emerald-500/30 flex items-center gap-1.5 animate-fadeIn">
            <Check className="w-4 h-4" /> Broadcast Successfully Dispatched
          </span>
        )}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Composer Form */}
        <div className="glass-panel p-5 lg:col-span-2 space-y-4">
          <h3 className="text-sm font-bold text-white flex items-center gap-2">
            <Send className="w-4 h-4 text-indigo-400" />
            <span>Compose Notification Broadcast</span>
          </h3>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Notification Title <span className="text-rose-400">*</span>
              </label>
              <input
                type="text"
                required
                maxLength={100}
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="e.g. New Spam Protection Update Available!"
                className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white placeholder-slate-600 focus:outline-none focus:border-indigo-500"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Message Body <span className="text-rose-400">*</span>
              </label>
              <textarea
                required
                rows={3}
                maxLength={300}
                value={body}
                onChange={(e) => setBody(e.target.value)}
                placeholder="e.g. Tap here to upgrade to JPhone Pro and enjoy zero ads and HD call recording."
                className="w-full bg-slate-950 border border-slate-800 rounded-lg p-3 text-xs text-white placeholder-slate-600 focus:outline-none focus:border-indigo-500"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Target Audience Segment
                </label>
                <select
                  value={targetAudience}
                  onChange={(e) => setTargetAudience(e.target.value as any)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-indigo-500"
                >
                  <option value="all">All JPhone Users (Topic: all)</option>
                  <option value="free_users">Free Tier Users Only</option>
                  <option value="premium_users">Active Premium Subscribers</option>
                  <option value="topic_announcements">System Announcements Channel</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  In-App Deep Link Destination
                </label>
                <input
                  type="text"
                  value={deepLink}
                  onChange={(e) => setDeepLink(e.target.value)}
                  placeholder="jphone://premium or jphone://settings"
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs font-mono text-white placeholder-slate-600 focus:outline-none focus:border-indigo-500"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Optional Banner Image Attachment URL (HTTPS)
              </label>
              <input
                type="url"
                value={imageUrl}
                onChange={(e) => setImageUrl(e.target.value)}
                placeholder="https://images.unsplash.com/photo-..."
                className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs font-mono text-white placeholder-slate-600 focus:outline-none focus:border-indigo-500"
              />
            </div>

            <div className="pt-2 flex justify-end">
              <button
                type="submit"
                disabled={!title.trim() || !body.trim()}
                className="px-5 py-2.5 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 rounded-xl shadow-lg shadow-indigo-900/30 flex items-center gap-2 transition-colors"
              >
                <Send className="w-4 h-4" />
                <span>Review &amp; Broadcast</span>
              </button>
            </div>
          </form>
        </div>

        {/* Live Android Notification Card Preview */}
        <div className="glass-panel p-5 space-y-4">
          <h3 className="text-sm font-bold text-white flex items-center gap-2">
            <Smartphone className="w-4 h-4 text-indigo-400" />
            <span>Android Push Preview</span>
          </h3>

          <div className="p-4 bg-slate-950 rounded-2xl border border-slate-800 shadow-2xl relative overflow-hidden">
            {/* Top Android System Bar Mock */}
            <div className="flex items-center justify-between text-[10px] text-slate-500 font-mono pb-2 border-b border-slate-800/80 mb-3">
              <span>12:00 PM</span>
              <div className="flex items-center gap-1.5">
                <span>5G</span>
                <span>100%</span>
              </div>
            </div>

            {/* Notification Card */}
            <div className="p-3.5 bg-slate-900/90 rounded-xl border border-slate-800 space-y-2">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="w-5 h-5 rounded-md bg-indigo-600 flex items-center justify-center text-[10px] text-white font-bold">
                    J
                  </div>
                  <span className="text-xs font-bold text-white">JPhone</span>
                  <span className="text-[10px] text-slate-500 font-mono">• now</span>
                </div>
              </div>

              <div>
                <div className="text-xs font-bold text-white leading-snug">
                  {title || 'Notification Headline Preview'}
                </div>
                <div className="text-xs text-slate-300 mt-1 leading-relaxed">
                  {body || 'Notification message body copy will appear here exactly as received on Android devices.'}
                </div>
              </div>

              {imageUrl && (
                <div className="mt-2 rounded-lg overflow-hidden border border-slate-800 max-h-36">
                  <img src={imageUrl} alt="Notification visual" className="w-full object-cover" />
                </div>
              )}

              {deepLink && (
                <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between text-[10px] text-indigo-400 font-mono">
                  <span>Target: {deepLink}</span>
                  <ExternalLink className="w-3 h-3" />
                </div>
              )}
            </div>
          </div>

          <div className="p-3 bg-slate-950 rounded-xl border border-slate-800/80 text-[11px] text-slate-400 space-y-1">
            <span className="font-semibold text-slate-300 block">Security Guardrail:</span>
            <span>Broadcasts require explicit confirmation and write immutable audit records to prevent unauthorized spam.</span>
          </div>
        </div>
      </div>

      {/* Broadcast History Table */}
      <div className="glass-panel p-5 space-y-4">
        <h3 className="text-sm font-bold text-white flex items-center gap-2">
          <Clock className="w-4 h-4 text-indigo-400" />
          <span>Broadcast Dispatch History</span>
        </h3>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400">
                <th className="pb-3 font-semibold">Notification</th>
                <th className="pb-3 font-semibold">Audience</th>
                <th className="pb-3 font-semibold">Delivery Count</th>
                <th className="pb-3 font-semibold">Dispatched By</th>
                <th className="pb-3 font-semibold text-right">Timestamp</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {notifications.map((notif) => (
                <tr key={notif.id} className="hover:bg-slate-800/30 transition-colors">
                  <td className="py-3 pr-3">
                    <div className="font-bold text-white">{notif.title}</div>
                    <div className="text-[11px] text-slate-400 truncate max-w-sm">{notif.body}</div>
                  </td>
                  <td className="py-3 pr-3">
                    <span className="text-[11px] font-mono px-2 py-0.5 rounded bg-slate-800 text-slate-300 border border-slate-700">
                      {notif.targetAudience}
                    </span>
                  </td>
                  <td className="py-3 pr-3 font-mono text-emerald-400">
                    {notif.deliveryCount ? notif.deliveryCount.toLocaleString() : 'Pending'}
                  </td>
                  <td className="py-3 pr-3 text-slate-400 font-mono text-[11px]">
                    {notif.sentByAdminId}
                  </td>
                  <td className="py-3 text-right font-mono text-slate-400 text-[11px]">
                    {new Date(notif.sentAt).toLocaleString()}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      <ConfirmDialog
        isOpen={isConfirmOpen}
        onClose={() => setIsConfirmOpen(false)}
        onConfirm={handleConfirmSend}
        title="Confirm Push Notification Broadcast"
        message={`Are you sure you want to broadcast "${title}" to segment [${targetAudience}]? This notification will be received on active JPhone Android devices.`}
        confirmLabel="Broadcast Now"
        isLoading={isSending}
      />
    </div>
  );
};
