import React, { useState } from 'react';
import { AppSettings } from '../types';
import { 
  MessageSquare, 
  Save, 
  ExternalLink, 
  Check, 
  Phone, 
  ShieldCheck, 
  AlertCircle,
  Copy,
  Smartphone
} from 'lucide-react';

interface WhatsAppPageProps {
  settings: AppSettings;
  onSaveSettings: (settings: AppSettings) => Promise<void>;
}

export const WhatsAppPage: React.FC<WhatsAppPageProps> = ({
  settings,
  onSaveSettings
}) => {
  const [phoneNumber, setPhoneNumber] = useState(settings.supportPhoneWhatsApp || '+923001234567');
  const [enabled, setEnabled] = useState(settings.whatsAppEnabled);
  const [defaultMessage, setDefaultMessage] = useState(
    settings.whatsAppDefaultMessage || 'Hello JPhone Support, I need assistance with my account.'
  );
  const [isSaving, setIsSaving] = useState(false);
  const [savedSuccess, setSavedSuccess] = useState(false);
  const [copiedLink, setCopiedLink] = useState(false);

  // Validate E.164 format: begins with +, followed by 8 to 15 digits
  const cleanNumber = phoneNumber.replace(/[^0-9]/g, '');
  const isValidE164 = phoneNumber.startsWith('+') && cleanNumber.length >= 8 && cleanNumber.length <= 15;

  // Generate safe wa.me link
  const generatedLink = cleanNumber 
    ? `https://wa.me/${cleanNumber}?text=${encodeURIComponent(defaultMessage)}`
    : '';

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!isValidE164) {
      alert('Please enter a valid international phone number in E.164 format starting with +, e.g. +923001234567');
      return;
    }

    setIsSaving(true);
    try {
      await onSaveSettings({
        ...settings,
        supportPhoneWhatsApp: phoneNumber.trim(),
        whatsAppEnabled: enabled,
        whatsAppDefaultMessage: defaultMessage.trim()
      });
      setSavedSuccess(true);
      setTimeout(() => setSavedSuccess(false), 2500);
    } finally {
      setIsSaving(false);
    }
  };

  const handleCopy = () => {
    if (!generatedLink) return;
    navigator.clipboard.writeText(generatedLink);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2000);
  };

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-white flex items-center gap-2">
            <MessageSquare className="w-5 h-5 text-emerald-400" />
            <span>WhatsApp Customer Support Integration</span>
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Configure official WhatsApp customer concierge channel and automated chat templates for Android app users.
          </p>
        </div>

        {savedSuccess && (
          <span className="text-xs font-semibold text-emerald-400 bg-emerald-500/10 px-3 py-1.5 rounded-lg border border-emerald-500/30 flex items-center gap-1.5">
            <Check className="w-4 h-4" /> WhatsApp Configuration Saved
          </span>
        )}
      </div>

      {/* Compliance / Privacy Policy Box */}
      <div className="p-4 rounded-xl bg-slate-900/80 border border-slate-800 text-xs text-slate-300 space-y-2">
        <div className="flex items-center gap-2 font-bold text-white">
          <ShieldCheck className="w-4 h-4 text-emerald-400" />
          <span>Security &amp; API Integrity Standard</span>
        </div>
        <p className="leading-relaxed text-slate-400">
          WhatsApp links use standard, privacy-preserving HTTPS <code className="text-emerald-400 font-mono">wa.me</code> redirects and native Android intents. JPhone does not collect or inspect WhatsApp credentials, private chat histories, or scrape phone registries without official API consent.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Settings Form */}
        <div className="glass-panel p-5 lg:col-span-2 space-y-5">
          <form onSubmit={handleSubmit} className="space-y-5">
            {/* Toggle switch */}
            <div className="flex items-center justify-between p-3.5 bg-slate-950 rounded-xl border border-slate-800">
              <div>
                <span className="font-semibold text-white text-xs block">Enable WhatsApp Support Link in Android App</span>
                <span className="text-slate-400 text-[11px] block mt-0.5">Controls visibility of the floating WhatsApp concierge button in JPhone.</span>
              </div>
              <input
                type="checkbox"
                checked={enabled}
                onChange={(e) => setEnabled(e.target.checked)}
                className="w-4 h-4 text-emerald-600 rounded bg-slate-900 border-slate-700 focus:ring-emerald-500 cursor-pointer"
              />
            </div>

            {/* Phone Number Input */}
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Official Support WhatsApp Phone Number (International E.164 Format) <span className="text-rose-400">*</span>
              </label>
              <div className="relative">
                <Phone className="w-4 h-4 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  required
                  value={phoneNumber}
                  onChange={(e) => setPhoneNumber(e.target.value)}
                  placeholder="+923001234567"
                  className={`w-full bg-slate-950 border rounded-lg pl-9 pr-3 py-2 text-xs font-mono text-white placeholder-slate-600 focus:outline-none ${
                    isValidE164 ? 'border-slate-800 focus:border-emerald-500' : 'border-rose-500/80'
                  }`}
                />
              </div>
              {!isValidE164 ? (
                <p className="text-[11px] text-rose-400 mt-1">Must start with country code (e.g. +92, +1, +44) with 8-15 digits.</p>
              ) : (
                <p className="text-[11px] text-slate-500 mt-1">International format ensures automatic routing across global mobile carriers.</p>
              )}
            </div>

            {/* Default Message */}
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Pre-filled Customer Inquiry Template
              </label>
              <textarea
                rows={3}
                value={defaultMessage}
                onChange={(e) => setDefaultMessage(e.target.value)}
                placeholder="e.g. Hello JPhone Support, I need help with caller ID verification."
                className="w-full bg-slate-950 border border-slate-800 rounded-lg p-3 text-xs text-white placeholder-slate-600 focus:outline-none focus:border-emerald-500"
              />
              <p className="text-[11px] text-slate-500 mt-1">Safely URL-encoded so the user's WhatsApp chat composer opens with this text ready to send.</p>
            </div>

            <div className="flex justify-end pt-2">
              <button
                type="submit"
                disabled={isSaving || !isValidE164}
                className="px-5 py-2.5 text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 rounded-xl shadow-lg shadow-emerald-900/30 flex items-center gap-2 transition-colors"
              >
                <Save className="w-4 h-4" />
                <span>{isSaving ? 'Saving...' : 'Save WhatsApp Configuration'}</span>
              </button>
            </div>
          </form>
        </div>

        {/* Live Preview Panel */}
        <div className="glass-panel p-5 space-y-4">
          <h3 className="text-sm font-bold text-white flex items-center gap-2">
            <Smartphone className="w-4 h-4 text-emerald-400" />
            <span>Interactive wa.me Preview</span>
          </h3>

          <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 space-y-3">
            <div className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
              Resolved Intent URL
            </div>
            <div className="p-2.5 bg-slate-900 rounded-lg border border-slate-800 font-mono text-[11px] text-emerald-400 break-all select-all">
              {generatedLink || 'Please enter a valid phone number'}
            </div>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={handleCopy}
                disabled={!generatedLink}
                className="flex-1 py-1.5 px-3 text-xs font-semibold text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 rounded-lg flex items-center justify-center gap-1.5 transition-colors"
              >
                {copiedLink ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copiedLink ? 'Copied Link' : 'Copy URL'}</span>
              </button>

              {generatedLink && (
                <a
                  href={generatedLink}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="py-1.5 px-3 text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-500 rounded-lg flex items-center gap-1.5 transition-colors"
                >
                  <ExternalLink className="w-3.5 h-3.5" />
                  <span>Test Link</span>
                </a>
              )}
            </div>
          </div>

          {/* Android Intent snippet */}
          <div className="space-y-1.5">
            <div className="text-[11px] font-bold text-slate-400">Android Kotlin Intent Implementation:</div>
            <pre className="p-3 bg-slate-950 rounded-lg border border-slate-800 text-[10px] font-mono text-slate-300 overflow-x-auto leading-relaxed">
{`val url = "https://wa.me/\${phone}?text=\${encodedMsg}"
val intent = Intent(Intent.ACTION_VIEW)
intent.data = Uri.parse(url)
context.startActivity(intent)`}
            </pre>
          </div>
        </div>
      </div>
    </div>
  );
};
