import React, { useState, useMemo } from 'react';
import { JPhoneUser, SubscriptionTier } from '../types';
import { TierBadge, Badge } from '../components/ui/Badge';
import { 
  Users, 
  Search, 
  Filter, 
  RefreshCw, 
  Mail, 
  Phone, 
  CheckCircle2, 
  XCircle, 
  Crown, 
  ShieldAlert, 
  ShieldCheck, 
  ChevronLeft, 
  ChevronRight,
  MoreVertical,
  ExternalLink
} from 'lucide-react';

interface UsersPageProps {
  users: JPhoneUser[];
  onRefresh: () => Promise<void>;
  onSelectUser: (user: JPhoneUser) => void;
  onOpenSuspend: (user: JPhoneUser) => void;
  onOpenGrantPremium: (user: JPhoneUser) => void;
  isLive: boolean;
}

export const UsersPage: React.FC<UsersPageProps> = ({
  users,
  onRefresh,
  onSelectUser,
  onOpenSuspend,
  onOpenGrantPremium,
  isLive
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [tierFilter, setTierFilter] = useState<'all' | 'free' | 'premium'>('all');
  const [statusFilter, setStatusFilter] = useState<'all' | 'active' | 'suspended'>('all');
  const [verificationFilter, setVerificationFilter] = useState<'all' | 'verified' | 'unverified'>('all');
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [currentPage, setCurrentPage] = useState(1);
  const pageSize = 10;

  const handleRefresh = async () => {
    setIsRefreshing(true);
    try {
      await onRefresh();
    } finally {
      setIsRefreshing(false);
    }
  };

  const filteredUsers = useMemo(() => {
    return users.filter(user => {
      // Search match
      const query = searchTerm.toLowerCase();
      const matchesSearch = 
        !searchTerm ||
        user.displayName?.toLowerCase().includes(query) ||
        user.email?.toLowerCase().includes(query) ||
        user.phoneNumber?.includes(query) ||
        user.id.toLowerCase().includes(query);

      // Tier filter
      const matchesTier = tierFilter === 'all' || user.subscriptionTier === tierFilter;

      // Status filter
      const matchesStatus = 
        statusFilter === 'all' ||
        (statusFilter === 'active' && !user.isSuspended) ||
        (statusFilter === 'suspended' && user.isSuspended);

      // Verification filter
      const isVerified = user.emailVerified || user.phoneVerified;
      const matchesVerification = 
        verificationFilter === 'all' ||
        (verificationFilter === 'verified' && isVerified) ||
        (verificationFilter === 'unverified' && !isVerified);

      return matchesSearch && matchesTier && matchesStatus && matchesVerification;
    });
  }, [users, searchTerm, tierFilter, statusFilter, verificationFilter]);

  const totalPages = Math.ceil(filteredUsers.length / pageSize) || 1;
  const paginatedUsers = filteredUsers.slice((currentPage - 1) * pageSize, currentPage * pageSize);

  return (
    <div className="space-y-5">
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-white flex items-center gap-2">
            <Users className="w-5 h-5 text-indigo-400" />
            <span>User Management</span>
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Authoritative directory of JPhone client accounts, verification tokens, and subscription entitlements.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleRefresh}
            disabled={isRefreshing}
            className="px-3 py-2 text-xs font-semibold text-slate-300 hover:text-white bg-slate-900 border border-slate-800 hover:bg-slate-800 rounded-xl flex items-center gap-1.5 transition-colors"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isRefreshing ? 'animate-spin' : ''}`} />
            <span>{isRefreshing ? 'Syncing...' : 'Refresh Records'}</span>
          </button>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="glass-panel p-4 space-y-3">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
          {/* Search box */}
          <div className="relative">
            <Search className="w-4 h-4 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => {
                setSearchTerm(e.target.value);
                setCurrentPage(1);
              }}
              placeholder="Search by name, email, phone, UID..."
              className="w-full bg-slate-950 border border-slate-800 rounded-lg pl-9 pr-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500 font-mono"
            />
          </div>

          {/* Tier Filter */}
          <div>
            <select
              value={tierFilter}
              onChange={(e) => {
                setTierFilter(e.target.value as any);
                setCurrentPage(1);
              }}
              className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-slate-300 focus:outline-none focus:border-indigo-500"
            >
              <option value="all">All Membership Tiers</option>
              <option value="free">Tier: FREE</option>
              <option value="premium">Tier: PREMIUM</option>
            </select>
          </div>

          {/* Status Filter */}
          <div>
            <select
              value={statusFilter}
              onChange={(e) => {
                setStatusFilter(e.target.value as any);
                setCurrentPage(1);
              }}
              className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-slate-300 focus:outline-none focus:border-indigo-500"
            >
              <option value="all">All Account Statuses</option>
              <option value="active">Active Only</option>
              <option value="suspended">Suspended Only</option>
            </select>
          </div>

          {/* Verification Filter */}
          <div>
            <select
              value={verificationFilter}
              onChange={(e) => {
                setVerificationFilter(e.target.value as any);
                setCurrentPage(1);
              }}
              className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-slate-300 focus:outline-none focus:border-indigo-500"
            >
              <option value="all">All Verification Statuses</option>
              <option value="verified">Verified (Email or Phone)</option>
              <option value="unverified">Unverified Only</option>
            </select>
          </div>
        </div>

        {/* Active Filters Bar */}
        <div className="flex items-center justify-between text-xs text-slate-400 pt-1">
          <div>
            Showing <span className="font-mono text-white font-semibold">{filteredUsers.length}</span> matching accounts (Page {currentPage} of {totalPages})
          </div>
          {(searchTerm || tierFilter !== 'all' || statusFilter !== 'all' || verificationFilter !== 'all') && (
            <button
              onClick={() => {
                setSearchTerm('');
                setTierFilter('all');
                setStatusFilter('all');
                setVerificationFilter('all');
                setCurrentPage(1);
              }}
              className="text-xs text-indigo-400 hover:text-indigo-300 underline"
            >
              Reset Filters
            </button>
          )}
        </div>
      </div>

      {/* Users Table */}
      <div className="glass-panel overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="bg-slate-950/80 border-b border-slate-800 text-slate-400">
                <th className="py-3 px-4 font-semibold">User Details</th>
                <th className="py-3 px-4 font-semibold">Membership Tier</th>
                <th className="py-3 px-4 font-semibold">Contact & Verification</th>
                <th className="py-3 px-4 font-semibold">Status</th>
                <th className="py-3 px-4 font-semibold">Last Seen</th>
                <th className="py-3 px-4 font-semibold text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {paginatedUsers.length === 0 ? (
                <tr>
                  <td colSpan={6} className="py-12 text-center text-slate-500">
                    No users match your query criteria.
                  </td>
                </tr>
              ) : (
                paginatedUsers.map((user) => (
                  <tr
                    key={user.id}
                    className="hover:bg-slate-800/30 transition-colors group"
                  >
                    {/* User Identity */}
                    <td className="py-3.5 px-4">
                      <div 
                        onClick={() => onSelectUser(user)}
                        className="font-bold text-white group-hover:text-indigo-300 transition-colors cursor-pointer flex items-center gap-1.5"
                      >
                        <span>{user.displayName || 'Unnamed User'}</span>
                      </div>
                      <div className="text-[11px] text-slate-500 font-mono mt-0.5">
                        {user.id}
                      </div>
                    </td>

                    {/* Tier Badge */}
                    <td className="py-3.5 px-4">
                      <TierBadge tier={user.subscriptionTier} size="md" />
                      {user.subscriptionExpiry && user.subscriptionTier === 'premium' && (
                        <div className="text-[10px] text-slate-500 font-mono mt-1">
                          Exp: {new Date(user.subscriptionExpiry).toLocaleDateString()}
                        </div>
                      )}
                    </td>

                    {/* Contact & Verification Badges */}
                    <td className="py-3.5 px-4 space-y-1">
                      <div className="flex items-center gap-1.5">
                        <Mail className="w-3 h-3 text-slate-500 shrink-0" />
                        <span className="text-slate-300 truncate max-w-[150px]">{user.email || '—'}</span>
                        {user.emailVerified ? (
                          <span className="text-[10px] text-emerald-400 bg-emerald-500/10 px-1.5 py-0.2 rounded border border-emerald-500/30" title="Email verified">
                            ✓
                          </span>
                        ) : (
                          <span className="text-[10px] text-slate-500">unverified</span>
                        )}
                      </div>
                      <div className="flex items-center gap-1.5 font-mono text-[11px]">
                        <Phone className="w-3 h-3 text-slate-500 shrink-0" />
                        <span className="text-slate-300">{user.phoneNumber || '—'}</span>
                        {user.phoneVerified ? (
                          <span className="text-[10px] text-emerald-400 bg-emerald-500/10 px-1.5 py-0.2 rounded border border-emerald-500/30" title="Phone OTP verified">
                            OTP ✓
                          </span>
                        ) : (
                          <span className="text-[10px] text-amber-400 bg-amber-500/10 px-1 py-0.2 rounded" title="Phone OTP not yet verified">
                            No OTP
                          </span>
                        )}
                      </div>
                    </td>

                    {/* Account Status */}
                    <td className="py-3.5 px-4">
                      <span className={`inline-flex items-center gap-1 text-[11px] font-semibold px-2 py-0.5 rounded border ${
                        user.isSuspended
                          ? 'bg-rose-500/10 text-rose-400 border-rose-500/30'
                          : 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30'
                      }`}>
                        {user.isSuspended ? 'Suspended' : 'Active'}
                      </span>
                      {user.suspendedReason && (
                        <div className="text-[10px] text-rose-300/70 truncate max-w-[130px] mt-0.5" title={user.suspendedReason}>
                          {user.suspendedReason}
                        </div>
                      )}
                    </td>

                    {/* Last seen */}
                    <td className="py-3.5 px-4 text-slate-400 font-mono text-[11px]">
                      {user.lastSeenAt ? new Date(user.lastSeenAt).toLocaleDateString() : '—'}
                    </td>

                    {/* Quick Action Buttons */}
                    <td className="py-3.5 px-4 text-right">
                      <div className="flex items-center justify-end gap-1.5">
                        <button
                          onClick={() => onSelectUser(user)}
                          className="px-2.5 py-1 text-[11px] font-medium text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 rounded-lg transition-colors"
                        >
                          View
                        </button>

                        <button
                          onClick={() => onOpenGrantPremium(user)}
                          className={`p-1.5 rounded-lg text-xs transition-colors ${
                            user.subscriptionTier === 'premium'
                              ? 'text-amber-400 hover:bg-amber-500/10'
                              : 'text-blue-400 hover:bg-blue-500/10'
                          }`}
                          title={user.subscriptionTier === 'premium' ? 'Revoke Premium' : 'Grant Premium'}
                        >
                          <Crown className="w-3.5 h-3.5" />
                        </button>

                        <button
                          onClick={() => onOpenSuspend(user)}
                          className={`p-1.5 rounded-lg text-xs transition-colors ${
                            user.isSuspended
                              ? 'text-emerald-400 hover:bg-emerald-500/10'
                              : 'text-rose-400 hover:bg-rose-500/10'
                          }`}
                          title={user.isSuspended ? 'Reactivate User' : 'Suspend User'}
                        >
                          {user.isSuspended ? <ShieldCheck className="w-3.5 h-3.5" /> : <ShieldAlert className="w-3.5 h-3.5" />}
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>

        {/* Pagination footer */}
        {totalPages > 1 && (
          <div className="p-4 border-t border-slate-800 flex items-center justify-between text-xs text-slate-400">
            <span>
              Showing {(currentPage - 1) * pageSize + 1} to {Math.min(currentPage * pageSize, filteredUsers.length)} of {filteredUsers.length} accounts
            </span>
            <div className="flex items-center gap-2">
              <button
                onClick={() => setCurrentPage(p => Math.max(1, p - 1))}
                disabled={currentPage === 1}
                className="p-1.5 rounded-lg bg-slate-800 text-slate-300 hover:text-white disabled:opacity-40 disabled:hover:bg-slate-800 transition-colors"
              >
                <ChevronLeft className="w-4 h-4" />
              </button>
              <span className="font-mono text-slate-200">
                {currentPage} / {totalPages}
              </span>
              <button
                onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))}
                disabled={currentPage === totalPages}
                className="p-1.5 rounded-lg bg-slate-800 text-slate-300 hover:text-white disabled:opacity-40 disabled:hover:bg-slate-800 transition-colors"
              >
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
