import React, { useState } from 'react';
import { 
  BookOpen, 
  Terminal, 
  ShieldCheck, 
  Globe, 
  Key, 
  Copy, 
  Check, 
  ExternalLink,
  ChevronRight,
  Database,
  Lock,
  Layers,
  Sparkles
} from 'lucide-react';

export const SetupGuidePage: React.FC = () => {
  const [copiedKey, setCopiedKey] = useState<string | null>(null);

  const copyToClipboard = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKey(id);
    setTimeout(() => setCopiedKey(null), 2000);
  };

  const codeSnippets = {
    install: `npm install`,
    build: `npm run build`,
    deployRules: `firebase deploy --only firestore:rules`,
    deployHosting: `firebase deploy --only hosting`,
    firstAdminScript: `// scripts/provision-first-admin.js
const admin = require('firebase-admin');
const serviceAccount = require('./service-account.json');

admin.initializeApp({
  credential: admin.credential.cert(serviceAccount)
});

const db = admin.firestore();

async function provisionAdmin(email, uid) {
  await db.collection('admins').doc(uid).set({
    id: uid,
    email: email,
    role: 'super_admin',
    assignedBy: 'system_bootstrap',
    assignedAt: new Date().toISOString(),
    active: true
  });
  console.log(\`Successfully provisioned super admin: \${email} (\${uid})\`);
}

provisionAdmin('attamuhammad6008@gmail.com', 'TARGET_FIREBASE_AUTH_UID');`
  };

  return (
    <div className="space-y-6 max-w-5xl">
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-white flex items-center gap-2">
            <BookOpen className="w-5 h-5 text-indigo-400" />
            <span>Hosting, Security &amp; Deployment Guide</span>
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Official standard operating procedure for JPhone Web Admin Panel setup, first-admin provisioning, and production deployment.
          </p>
        </div>

        <span className="text-xs font-mono bg-indigo-500/10 text-indigo-400 border border-indigo-500/30 px-3 py-1 rounded-full">
          Production Architecture
        </span>
      </div>

      {/* 10-Step Guide Accordion / Cards */}
      <div className="space-y-4">
        {/* Step 1: Dependencies */}
        <div className="glass-panel p-5 space-y-3">
          <div className="flex items-center gap-3">
            <span className="w-7 h-7 rounded-lg bg-indigo-600 flex items-center justify-center font-bold font-mono text-xs text-white">1</span>
            <h3 className="text-sm font-bold text-white">Install Dependencies</h3>
          </div>
          <p className="text-xs text-slate-300 leading-relaxed">
            Run the standard package manager command in the root of the project to install required client libraries and build tools:
          </p>
          <div className="relative">
            <pre className="p-3 bg-slate-950 rounded-xl border border-slate-800 text-xs font-mono text-indigo-300">
              {codeSnippets.install}
            </pre>
            <button
              onClick={() => copyToClipboard(codeSnippets.install, 'install')}
              className="absolute right-3 top-2.5 p-1.5 rounded-lg text-slate-400 hover:text-white bg-slate-800 hover:bg-slate-700"
            >
              {copiedKey === 'install' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
            </button>
          </div>
        </div>

        {/* Step 2: Frontend Environment Configuration */}
        <div className="glass-panel p-5 space-y-3">
          <div className="flex items-center gap-3">
            <span className="w-7 h-7 rounded-lg bg-indigo-600 flex items-center justify-center font-bold font-mono text-xs text-white">2</span>
            <h3 className="text-sm font-bold text-white">Configure Public Frontend Environment Variables</h3>
          </div>
          <p className="text-xs text-slate-300 leading-relaxed">
            Copy <code className="text-indigo-400 font-mono">.env.example</code> to <code className="text-indigo-400 font-mono">.env</code> and fill in your Firebase public Web App keys. Alternatively, click the mode pill in the top header to enter them directly into browser local storage for instant live testing.
          </p>
          <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 text-[11px] font-mono text-slate-400 space-y-1">
            <div>VITE_FIREBASE_API_KEY="AIzaSy..."</div>
            <div>VITE_FIREBASE_PROJECT_ID="your-jphone-project"</div>
            <div>VITE_FIREBASE_AUTH_DOMAIN="your-jphone-project.firebaseapp.com"</div>
          </div>
        </div>

        {/* Step 3 & 4: Secure First Administrator Provisioning */}
        <div className="glass-panel p-5 space-y-3 border-indigo-500/30">
          <div className="flex items-center gap-3">
            <span className="w-7 h-7 rounded-lg bg-indigo-600 flex items-center justify-center font-bold font-mono text-xs text-white">3</span>
            <h3 className="text-sm font-bold text-white">Secure First Administrator Provisioning (CRITICAL)</h3>
          </div>
          <div className="p-3 rounded-xl bg-amber-500/10 border border-amber-500/20 text-xs text-amber-300">
            <span className="font-bold text-white">Zero Trust Principle:</span> Users never become administrators merely by signing up. Client-side role claims are forbidden. The security rules strictly check <code className="text-white font-mono">exists(/databases/$(database)/documents/admins/$(request.auth.uid))</code>.
          </div>
          <p className="text-xs text-slate-300 leading-relaxed">
            To provision your account (<code className="text-indigo-300 font-semibold">attamuhammad6008@gmail.com</code>) as the first Super Admin, execute the trusted backend script using your Google Cloud Service Account:
          </p>
          <div className="relative">
            <pre className="p-3 bg-slate-950 rounded-xl border border-slate-800 text-[11px] font-mono text-slate-300 overflow-x-auto leading-relaxed">
              {codeSnippets.firstAdminScript}
            </pre>
            <button
              onClick={() => copyToClipboard(codeSnippets.firstAdminScript, 'script')}
              className="absolute right-3 top-2.5 p-1.5 rounded-lg text-slate-400 hover:text-white bg-slate-800 hover:bg-slate-700"
            >
              {copiedKey === 'script' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
            </button>
          </div>
        </div>

        {/* Step 5: Firestore Rules Deployment */}
        <div className="glass-panel p-5 space-y-3">
          <div className="flex items-center gap-3">
            <span className="w-7 h-7 rounded-lg bg-indigo-600 flex items-center justify-center font-bold font-mono text-xs text-white">4</span>
            <h3 className="text-sm font-bold text-white">Deploy Hardened Firestore Security Rules</h3>
          </div>
          <p className="text-xs text-slate-300 leading-relaxed">
            The included <code className="text-indigo-400 font-mono">firestore.rules</code> file enforces Attribute-Based Access Control (ABAC), preventing standard users from modifying subscription tiers or tampering with immutable audit trails. Deploy using Firebase CLI:
          </p>
          <div className="relative">
            <pre className="p-3 bg-slate-950 rounded-xl border border-slate-800 text-xs font-mono text-indigo-300">
              {codeSnippets.deployRules}
            </pre>
            <button
              onClick={() => copyToClipboard(codeSnippets.deployRules, 'rules')}
              className="absolute right-3 top-2.5 p-1.5 rounded-lg text-slate-400 hover:text-white bg-slate-800 hover:bg-slate-700"
            >
              {copiedKey === 'rules' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
            </button>
          </div>
        </div>

        {/* Step 6: Firebase Hosting Deployment */}
        <div className="glass-panel p-5 space-y-3">
          <div className="flex items-center gap-3">
            <span className="w-7 h-7 rounded-lg bg-indigo-600 flex items-center justify-center font-bold font-mono text-xs text-white">5</span>
            <h3 className="text-sm font-bold text-white">Build &amp; Deploy to Firebase Hosting</h3>
          </div>
          <p className="text-xs text-slate-300 leading-relaxed">
            Compile the production web bundle and deploy to Firebase Hosting:
          </p>
          <div className="relative">
            <pre className="p-3 bg-slate-950 rounded-xl border border-slate-800 text-xs font-mono text-indigo-300">
              {codeSnippets.build} && {codeSnippets.deployHosting}
            </pre>
            <button
              onClick={() => copyToClipboard(`${codeSnippets.build} && ${codeSnippets.deployHosting}`, 'deploy')}
              className="absolute right-3 top-2.5 p-1.5 rounded-lg text-slate-400 hover:text-white bg-slate-800 hover:bg-slate-700"
            >
              {copiedKey === 'deploy' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
            </button>
          </div>
        </div>

        {/* Step 7: Authorized Domains */}
        <div className="glass-panel p-5 space-y-3">
          <div className="flex items-center gap-3">
            <span className="w-7 h-7 rounded-lg bg-indigo-600 flex items-center justify-center font-bold font-mono text-xs text-white">6</span>
            <h3 className="text-sm font-bold text-white">Configure Firebase Authentication Authorized Domains</h3>
          </div>
          <p className="text-xs text-slate-300 leading-relaxed">
            In Firebase Console &gt; Authentication &gt; Settings &gt; Authorized domains, add your web hosting domain (e.g. <code className="text-indigo-400 font-mono">jphone-admin.web.app</code> or your custom domain). Without this, Google Sign-in will block authentication popups.
          </p>
        </div>
      </div>
    </div>
  );
};
