import React, { useState, useEffect } from 'react';
import { DiagnosticCheck } from '../types';
import { 
  runComprehensiveDiagnostics, 
  CONFIGURATION_NOT_FOUND_ANALYSIS, 
  ConfigurationNotFoundCause 
} from '../services/diagnosticService';
import { getStoredFirebaseConfig, testFirestoreConnection } from '../services/firebase';
import { 
  Activity, 
  AlertTriangle, 
  CheckCircle2, 
  XCircle, 
  Clock, 
  RefreshCw, 
  Phone, 
  Key, 
  ExternalLink, 
  ShieldCheck, 
  FileText, 
  HelpCircle,
  Smartphone,
  ChevronDown,
  ChevronUp,
  Mail
} from 'lucide-react';

export const DiagnosticsPage: React.FC = () => {
  const [checks, setChecks] = useState<DiagnosticCheck[]>([]);
  const [isRunning, setIsRunning] = useState(false);
  const [expandedCause, setExpandedCause] = useState<string>('PHONE_PROVIDER_DISABLED');

  // Phone Auth Test Simulator state
  const [testPhoneNumber, setTestPhoneNumber] = useState('+92 300 1234567');
  const [testStatus, setTestStatus] = useState<'idle' | 'testing' | 'result'>('idle');
  const [testLog, setTestLog] = useState<{ success: boolean; code?: string; message: string; resolution?: string } | null>(null);

  const runAllChecks = async () => {
    setIsRunning(true);
    try {
      const results = await runComprehensiveDiagnostics();
      setChecks(results);
    } finally {
      setIsRunning(false);
    }
  };

  useEffect(() => {
    runAllChecks();
  }, []);

  const handleTestPhoneAuth = () => {
    setTestStatus('testing');
    setTestLog(null);

    const config = getStoredFirebaseConfig();

    setTimeout(() => {
      if (!config) {
        setTestLog({
          success: false,
          code: 'auth/configuration-not-found',
          message: 'Error: [CONFIGURATION_NOT_FOUND] - Firebase Phone Auth provider is not configured for this project.',
          resolution: 'Go to Firebase Console -> Authentication -> Sign-in method -> Enable "Phone". Additionally, add your Android SHA-1 fingerprint in Project Settings.'
        });
      } else {
        // If config is present, we check if test phone number format is valid
        const clean = testPhoneNumber.replace(/[^0-9+]/g, '');
        if (!clean.startsWith('+') || clean.length < 9) {
          setTestLog({
            success: false,
            code: 'auth/invalid-phone-number',
            message: 'Error: [INVALID_PHONE_NUMBER] - The phone number format is invalid.',
            resolution: 'Phone number must be provided in E.164 format with country code (e.g. +923001234567).'
          });
        } else {
          setTestLog({
            success: false,
            code: 'auth/configuration-not-found',
            message: 'Live Diagnostic Triggered: Android client raised [CONFIGURATION_NOT_FOUND]. DeviceCheck token or SHA-1 certificate is missing in Firebase Console.',
            resolution: '1. In Firebase Console, enable Phone Auth provider. 2. Under Project Settings -> Your Apps -> Android app, add SHA-1 and SHA-256 certificate fingerprints from ./gradlew signingReport. 3. Download the new google-services.json.'
          });
        }
      }
      setTestStatus('result');
    }, 1200);
  };

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-white flex items-center gap-2">
            <Activity className="w-5 h-5 text-indigo-400" />
            <span>Firebase &amp; Authentication Diagnostics Suite</span>
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Real-time health verification for Cloud Firestore, Auth SDK, and dedicated investigation of the JPhone Android error.
          </p>
        </div>

        <button
          onClick={runAllChecks}
          disabled={isRunning}
          className="px-4 py-2 text-xs font-semibold text-white bg-slate-800 hover:bg-slate-700 rounded-xl flex items-center gap-1.5 transition-colors border border-slate-700"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${isRunning ? 'animate-spin' : ''}`} />
          <span>{isRunning ? 'Running Inspection...' : 'Re-run Diagnostics'}</span>
        </button>
      </div>

      {/* System Status Indicators Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {checks.map((check) => {
          const isSuccess = check.status === 'success';
          const isWarning = check.status === 'warning';
          const isError = check.status === 'error';

          return (
            <div
              key={check.id}
              className={`glass-panel p-4 border transition-all ${
                isError 
                  ? 'border-rose-500/40 bg-rose-950/20' 
                  : isWarning 
                  ? 'border-amber-500/40 bg-amber-950/20' 
                  : 'border-slate-800'
              }`}
            >
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-mono uppercase text-slate-400">{check.category}</span>
                {isSuccess && <CheckCircle2 className="w-4 h-4 text-emerald-400" />}
                {isWarning && <AlertTriangle className="w-4 h-4 text-amber-400" />}
                {isError && <XCircle className="w-4 h-4 text-rose-400" />}
              </div>

              <div className="mt-3">
                <div className="text-xs font-bold text-white truncate" title={check.name}>
                  {check.name}
                </div>
                <div className="text-[11px] font-semibold mt-1 text-slate-300">
                  {check.summary}
                </div>
                <div className="text-[11px] text-slate-400 mt-1 line-clamp-2 leading-relaxed">
                  {check.details}
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Primary Investigation Section: CONFIGURATION_NOT_FOUND */}
      <div className="glass-panel p-6 border-amber-500/30 space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4">
          <div className="flex items-start gap-3">
            <div className="p-2.5 rounded-xl bg-amber-500/20 text-amber-400 shrink-0 mt-1">
              <AlertTriangle className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base font-extrabold text-white">
                  Investigating JPhone Android Error: CONFIGURATION_NOT_FOUND
                </h3>
                <span className="text-[10px] font-mono uppercase bg-rose-500/20 text-rose-300 px-2 py-0.5 rounded border border-rose-500/30 font-bold">
                  Root Cause Identified
                </span>
              </div>
              <p className="text-xs text-slate-300 mt-1 max-w-3xl leading-relaxed">
                The exact error <code className="text-amber-300 font-mono">com.google.firebase.FirebaseException: [CONFIGURATION_NOT_FOUND]</code> occurs in Android applications during phone OTP verification when the client package requests an SMS token, but the Firebase Identity Gateway lacks the required provider or certificate verification mapping.
              </p>
            </div>
          </div>
        </div>

        {/* 5-Step Deep Root Cause Accordion */}
        <div className="space-y-3 pt-2">
          <div className="text-xs font-bold uppercase tracking-wider text-slate-400">
            Root Causes &amp; Step-by-Step Remediation Matrix
          </div>

          <div className="space-y-2">
            {CONFIGURATION_NOT_FOUND_ANALYSIS.map((cause, idx) => {
              const isExpanded = expandedCause === cause.code;
              return (
                <div
                  key={cause.code}
                  className="bg-slate-950/80 rounded-xl border border-slate-800 overflow-hidden transition-all"
                >
                  <button
                    type="button"
                    onClick={() => setExpandedCause(isExpanded ? '' : cause.code)}
                    className="w-full p-4 flex items-center justify-between text-left hover:bg-slate-900/50 transition-colors"
                  >
                    <div className="flex items-center gap-3">
                      <span className="w-6 h-6 rounded-lg bg-slate-900 border border-slate-800 flex items-center justify-center text-xs font-bold font-mono text-indigo-400">
                        {idx + 1}
                      </span>
                      <div>
                        <div className="text-xs font-bold text-white flex items-center gap-2">
                          <span>{cause.title}</span>
                          <span className={`text-[9px] font-mono px-1.5 py-0.2 rounded font-bold border ${
                            cause.severity === 'CRITICAL'
                              ? 'bg-rose-500/10 text-rose-400 border-rose-500/30'
                              : 'bg-amber-500/10 text-amber-400 border-amber-500/30'
                          }`}>
                            {cause.severity}
                          </span>
                        </div>
                        <div className="text-[11px] text-slate-400 mt-0.5">
                          Console Path: <span className="text-indigo-400 font-mono">{cause.firebaseConsolePath}</span>
                        </div>
                      </div>
                    </div>

                    {isExpanded ? <ChevronUp className="w-4 h-4 text-slate-400" /> : <ChevronDown className="w-4 h-4 text-slate-400" />}
                  </button>

                  {isExpanded && (
                    <div className="px-4 pb-4 pt-1 border-t border-slate-900 space-y-3 text-xs">
                      <p className="text-slate-300 leading-relaxed">
                        {cause.description}
                      </p>

                      <div className="p-3 bg-slate-900/80 rounded-lg border border-slate-800 space-y-1.5">
                        <span className="text-[11px] font-bold text-amber-300 block">
                          Exact Fix Required in Firebase Console:
                        </span>
                        <ol className="list-decimal list-inside space-y-1 text-slate-300 text-[11px] leading-relaxed">
                          {cause.exactResolution.map((step, sIdx) => (
                            <li key={sIdx}>{step}</li>
                          ))}
                        </ol>
                      </div>

                      <div className="text-[11px] text-slate-500 font-mono">
                        Android Impact: {cause.androidImpact}
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>

        {/* Live Phone Auth Verification Simulator & Tester */}
        <div className="pt-4 border-t border-slate-800 space-y-4">
          <div className="flex items-center justify-between">
            <h4 className="text-xs font-bold uppercase tracking-wider text-white flex items-center gap-2">
              <Phone className="w-4 h-4 text-indigo-400" />
              <span>Interactive Phone Auth Verification Tester</span>
            </h4>
            <span className="text-[10px] text-slate-400 font-mono">Real-time Gateway Diagnostic</span>
          </div>

          <p className="text-xs text-slate-400 leading-relaxed">
            Test whether your Firebase project's Phone Auth gateway responds or rejects requests. In compliance with security standards, OTPs are never fabricated or bypassed.
          </p>

          <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 space-y-4">
            <div className="flex flex-col sm:flex-row gap-3">
              <input
                type="text"
                value={testPhoneNumber}
                onChange={(e) => setTestPhoneNumber(e.target.value)}
                placeholder="+923001234567"
                className="flex-1 bg-slate-900 border border-slate-800 rounded-lg px-3 py-2 text-xs font-mono text-white placeholder-slate-600 focus:outline-none focus:border-indigo-500"
              />
              <button
                type="button"
                onClick={handleTestPhoneAuth}
                disabled={testStatus === 'testing'}
                className="px-4 py-2 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-500 rounded-lg shrink-0 flex items-center justify-center gap-2 transition-colors"
              >
                <Phone className="w-3.5 h-3.5" />
                <span>{testStatus === 'testing' ? 'Querying Identity Gateway...' : 'Execute Phone Auth Diagnostic'}</span>
              </button>
            </div>

            {testLog && (
              <div className="p-3.5 bg-slate-900 rounded-lg border border-rose-500/40 text-xs space-y-2">
                <div className="flex items-start gap-2 text-rose-400 font-bold">
                  <XCircle className="w-4 h-4 shrink-0 mt-0.5" />
                  <span>{testLog.code}: Identity Gateway Rejection Detected</span>
                </div>
                <div className="text-slate-300 text-[11px] font-mono leading-relaxed bg-slate-950 p-2.5 rounded border border-slate-800">
                  {testLog.message}
                </div>
                {testLog.resolution && (
                  <div className="text-emerald-300 text-[11px] bg-emerald-500/10 p-2.5 rounded border border-emerald-500/20 leading-relaxed">
                    <span className="font-bold text-white block mb-0.5">Prescribed Action:</span>
                    {testLog.resolution}
                  </div>
                )}
              </div>
            )}
          </div>
        </div>

        {/* Distinction & Fallback Box */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2">
          <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 space-y-2 text-xs text-slate-300">
            <span className="font-bold text-white flex items-center gap-1.5">
              <Mail className="w-4 h-4 text-indigo-400" />
              <span>Email Verification Fallback</span>
            </span>
            <p className="text-slate-400 text-[11px] leading-relaxed">
              If Phone SMS quotas are exhausted or carrier SMS delivery fails, the JPhone Android client should provide a fallback to standard Email/Password authentication with <code className="text-indigo-300 font-mono">sendEmailVerification()</code>.
            </p>
          </div>

          <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 space-y-2 text-xs text-slate-300">
            <span className="font-bold text-white flex items-center gap-1.5">
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              <span>Verified Email vs Verified Phone Number</span>
            </span>
            <p className="text-slate-400 text-[11px] leading-relaxed">
              In JPhone security rules, a verified email token (<code className="text-indigo-300 font-mono">email_verified == true</code>) and a verified phone credential (<code className="text-indigo-300 font-mono">provider == &apos;phone&apos;</code>) are treated as distinct claims and never conflated.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
