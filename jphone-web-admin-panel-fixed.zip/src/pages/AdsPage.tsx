import React, { useState } from 'react';
import { AppSettings } from '../types';
import { 
  Megaphone, 
  Save, 
  Check, 
  AlertTriangle, 
  ShieldAlert, 
  Smartphone, 
  Eye, 
  FileCode,
  DollarSign
} from 'lucide-react';

interface AdsPageProps {
  settings: AppSettings;
  onSaveSettings: (settings: AppSettings) => Promise<void>;
}

export const AdsPage: React.FC<AdsPageProps> = ({
  settings,
  onSaveSettings
}) => {
  const [formData, setFormData] = useState<AppSettings>({ ...settings });
  const [isSaving, setIsSaving] = useState(false);
  const [savedSuccess, setSavedSuccess] = useState(false);

  React.useEffect(() => {
    setFormData({ ...settings });
  }, [settings]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSaving(true);
    try {
      await onSaveSettings(formData);
      setSavedSuccess(true);
      setTimeout(() => setSavedSuccess(false), 2500);
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-white flex items-center gap-2">
            <Megaphone className="w-5 h-5 text-indigo-400" />
            <span>Advertising Management</span>
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Configure SDK placements for Google AdMob, AppLovin, and Unity Ads served to Free tier JPhone users.
          </p>
        </div>

        {savedSuccess && (
          <span className="text-xs font-semibold text-emerald-400 bg-emerald-500/10 px-3 py-1.5 rounded-lg border border-emerald-500/30 flex items-center gap-1.5">
            <Check className="w-4 h-4" /> Ad Configuration Published
          </span>
        )}
      </div>

      {/* Safety & Compliance Policy Card */}
      <div className="p-4 rounded-xl bg-slate-900/80 border border-slate-800 text-xs text-slate-300 space-y-2">
        <div className="flex items-center gap-2 font-bold text-white">
          <AlertTriangle className="w-4 h-4 text-amber-400" />
          <span>Google AdMob Compliance &amp; Zero-Fraud Guarantee</span>
        </div>
        <p className="leading-relaxed text-slate-400">
          Always retain <code className="text-amber-400 font-mono">test_ads_mode: true</code> while testing on internal developer devices. Clicking your own production ads or dispatching automated impressions violates Google Publisher Policies and leads to immediate account termination. Revenue reporting is currently pending direct AdMob API linkage.
        </p>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        {/* Master Switches */}
        <div className="glass-panel p-5 space-y-4">
          <h3 className="text-sm font-bold text-white">Master Switches &amp; Environment</h3>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="flex items-center justify-between p-3.5 bg-slate-950 rounded-xl border border-slate-800">
              <div>
                <span className="font-semibold text-white text-xs block">Global Ads Switch</span>
                <span className="text-slate-400 text-[11px] block mt-0.5">Toggle to instantly suspend all in-app ads across the network.</span>
              </div>
              <input
                type="checkbox"
                checked={formData.adsEnabled}
                onChange={(e) => setFormData({ ...formData, adsEnabled: e.target.checked })}
                className="w-4 h-4 text-indigo-600 rounded bg-slate-900 border-slate-700 focus:ring-indigo-500 cursor-pointer"
              />
            </div>

            <div className="flex items-center justify-between p-3.5 bg-slate-950 rounded-xl border border-slate-800">
              <div>
                <span className="font-semibold text-amber-300 text-xs block">Test Mode (Sample Ad Units)</span>
                <span className="text-slate-400 text-[11px] block mt-0.5">Loads Google standard sample test ads to prevent policy strikes.</span>
              </div>
              <input
                type="checkbox"
                checked={formData.testAdsMode}
                onChange={(e) => setFormData({ ...formData, testAdsMode: e.target.checked })}
                className="w-4 h-4 text-amber-600 rounded bg-slate-900 border-slate-700 focus:ring-amber-500 cursor-pointer"
              />
            </div>
          </div>
        </div>

        {/* Google AdMob Configuration */}
        <div className="glass-panel p-5 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <Smartphone className="w-4 h-4 text-indigo-400" />
              <span>Google AdMob Placements (Android)</span>
            </h3>
            <span className="text-[10px] font-mono uppercase bg-indigo-500/10 text-indigo-400 px-2 py-0.5 rounded border border-indigo-500/30">
              Primary Network
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                AdMob App ID (Android)
              </label>
              <input
                type="text"
                value={formData.adMobAppId}
                onChange={(e) => setFormData({ ...formData, adMobAppId: e.target.value })}
                placeholder="ca-app-pub-XXXXXXXXXXXXXXXX~XXXXXXXXXX"
                className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs font-mono text-white placeholder-slate-600 focus:outline-none focus:border-indigo-500"
              />
              <p className="text-[11px] text-slate-500 mt-1">Configured in AndroidManifest.xml &lt;meta-data&gt;.</p>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Banner Ad Unit ID
              </label>
              <input
                type="text"
                value={formData.adMobBannerId}
                onChange={(e) => setFormData({ ...formData, adMobBannerId: e.target.value })}
                placeholder="ca-app-pub-XXXXXXXXXXXXXXXX/XXXXXXXXXX"
                className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs font-mono text-white placeholder-slate-600 focus:outline-none focus:border-indigo-500"
              />
              <p className="text-[11px] text-slate-500 mt-1">Displayed on call history &amp; contact screens.</p>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Interstitial Ad Unit ID
              </label>
              <input
                type="text"
                value={formData.adMobInterstitialId}
                onChange={(e) => setFormData({ ...formData, adMobInterstitialId: e.target.value })}
                placeholder="ca-app-pub-XXXXXXXXXXXXXXXX/XXXXXXXXXX"
                className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs font-mono text-white placeholder-slate-600 focus:outline-none focus:border-indigo-500"
              />
              <p className="text-[11px] text-slate-500 mt-1">Displayed upon ending phone calls.</p>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Rewarded Video Ad Unit ID
              </label>
              <input
                type="text"
                value={formData.adMobRewardedId}
                onChange={(e) => setFormData({ ...formData, adMobRewardedId: e.target.value })}
                placeholder="ca-app-pub-XXXXXXXXXXXXXXXX/XXXXXXXXXX"
                className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs font-mono text-white placeholder-slate-600 focus:outline-none focus:border-indigo-500"
              />
              <p className="text-[11px] text-slate-500 mt-1">Grants Free users 24h temporary ad-free calling.</p>
            </div>
          </div>
        </div>

        {/* Mediation Networks (AppLovin & Unity Ads) */}
        <div className="glass-panel p-5 space-y-4">
          <h3 className="text-sm font-bold text-white">Mediation &amp; Fallback Networks</h3>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                AppLovin MAX SDK Key
              </label>
              <input
                type="text"
                value={formData.appLovinKey}
                onChange={(e) => setFormData({ ...formData, appLovinKey: e.target.value })}
                placeholder="AppLovin SDK Key"
                className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs font-mono text-white placeholder-slate-600 focus:outline-none focus:border-indigo-500"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Unity Ads Game ID (Android)
              </label>
              <input
                type="text"
                value={formData.unityGameId}
                onChange={(e) => setFormData({ ...formData, unityGameId: e.target.value })}
                placeholder="e.g. 5432100"
                className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs font-mono text-white placeholder-slate-600 focus:outline-none focus:border-indigo-500"
              />
            </div>
          </div>
        </div>

        {/* Action Button */}
        <div className="flex justify-end">
          <button
            type="submit"
            disabled={isSaving}
            className="px-5 py-2.5 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-500 rounded-xl shadow-lg shadow-indigo-900/30 flex items-center gap-2 transition-colors"
          >
            <Save className="w-4 h-4" />
            <span>{isSaving ? 'Deploying Changes...' : 'Save & Publish Ad Configuration'}</span>
          </button>
        </div>
      </form>
    </div>
  );
};
