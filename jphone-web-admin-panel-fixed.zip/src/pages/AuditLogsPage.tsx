import React, { useState, useMemo } from 'react';
import { AuditLog } from '../types';
import { Modal } from '../components/ui/Modal';
import { 
  FileText, 
  Search, 
  Filter, 
  Clock, 
  Shield, 
  User, 
  Settings, 
  Crown, 
  Bell, 
  CreditCard,
  ChevronRight,
  Eye
} from 'lucide-react';

interface AuditLogsPageProps {
  auditLogs: AuditLog[];
}

export const AuditLogsPage: React.FC<AuditLogsPageProps> = ({ auditLogs }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [actionFilter, setActionFilter] = useState<string>('all');
  const [selectedLog, setSelectedLog] = useState<AuditLog | null>(null);

  const filteredLogs = useMemo(() => {
    return auditLogs.filter(log => {
      const query = searchTerm.toLowerCase();
      const matchesSearch = 
        !searchTerm ||
        log.summary.toLowerCase().includes(query) ||
        log.adminEmail.toLowerCase().includes(query) ||
        log.targetId.toLowerCase().includes(query);

      const matchesAction = actionFilter === 'all' || log.action === actionFilter;

      return matchesSearch && matchesAction;
    });
  }, [auditLogs, searchTerm, actionFilter]);

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-white flex items-center gap-2">
            <FileText className="w-5 h-5 text-indigo-400" />
            <span>Administrative Audit Logs</span>
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Immutable security ledger tracking administrative interventions, user status modifications, and release deployments.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <span className="text-[11px] font-mono text-emerald-400 bg-emerald-500/10 px-3 py-1.5 rounded-lg border border-emerald-500/30 flex items-center gap-1.5">
            <Shield className="w-3.5 h-3.5" /> Append-Only &amp; Immutable
          </span>
        </div>
      </div>

      {/* Filter & Search */}
      <div className="glass-panel p-4 flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="w-4 h-4 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search audit trail by summary, admin, target ID..."
            className="w-full bg-slate-950 border border-slate-800 rounded-lg pl-9 pr-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500 font-mono"
          />
        </div>

        <div className="w-full sm:w-64">
          <select
            value={actionFilter}
            onChange={(e) => setActionFilter(e.target.value)}
            className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-slate-300 focus:outline-none focus:border-indigo-500"
          >
            <option value="all">All Action Types</option>
            <option value="LOGIN">Administrator Logins</option>
            <option value="USER_SUSPENDED">User Suspensions</option>
            <option value="USER_REACTIVATED">User Reactivations</option>
            <option value="PREMIUM_GRANTED">Premium Grants</option>
            <option value="PREMIUM_REVOKED">Premium Revocations</option>
            <option value="SETTINGS_UPDATED">Settings Updates</option>
            <option value="NOTIFICATION_BROADCAST">Push Broadcasts</option>
            <option value="PLAN_UPDATED">Plan Modifications</option>
          </select>
        </div>
      </div>

      {/* Logs Table */}
      <div className="glass-panel overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="bg-slate-950/80 border-b border-slate-800 text-slate-400">
                <th className="py-3 px-4 font-semibold">Action</th>
                <th className="py-3 px-4 font-semibold">Summary</th>
                <th className="py-3 px-4 font-semibold">Administrator</th>
                <th className="py-3 px-4 font-semibold">Target Ref</th>
                <th className="py-3 px-4 font-semibold">Timestamp</th>
                <th className="py-3 px-4 font-semibold text-right">Details</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {filteredLogs.length === 0 ? (
                <tr>
                  <td colSpan={6} className="py-12 text-center text-slate-500">
                    No audit records match your filters.
                  </td>
                </tr>
              ) : (
                filteredLogs.map((log) => (
                  <tr key={log.id} className="hover:bg-slate-800/30 transition-colors">
                    <td className="py-3.5 px-4">
                      <span className={`inline-flex items-center gap-1 font-mono text-[10px] uppercase font-bold px-2 py-0.5 rounded border ${
                        log.action.includes('PREMIUM')
                          ? 'bg-blue-500/10 text-blue-400 border-blue-500/30'
                          : log.action.includes('SUSPEND')
                          ? 'bg-rose-500/10 text-rose-400 border-rose-500/30'
                          : log.action.includes('SETTINGS')
                          ? 'bg-indigo-500/10 text-indigo-400 border-indigo-500/30'
                          : 'bg-slate-800 text-slate-300 border-slate-700'
                      }`}>
                        {log.action}
                      </span>
                    </td>

                    <td className="py-3.5 px-4">
                      <div className="font-semibold text-white max-w-md truncate" title={log.summary}>
                        {log.summary}
                      </div>
                    </td>

                    <td className="py-3.5 px-4 text-slate-300 font-mono text-[11px]">
                      {log.adminEmail}
                    </td>

                    <td className="py-3.5 px-4 font-mono text-slate-400 text-[11px]">
                      <span className="text-[10px] text-slate-500 uppercase mr-1">[{log.targetType}]</span>
                      {log.targetId}
                    </td>

                    <td className="py-3.5 px-4 font-mono text-slate-400 text-[11px]">
                      {new Date(log.timestamp).toLocaleString()}
                    </td>

                    <td className="py-3.5 px-4 text-right">
                      <button
                        onClick={() => setSelectedLog(log)}
                        className="px-2.5 py-1 text-[11px] font-semibold text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 rounded-lg flex items-center gap-1 ml-auto transition-colors"
                      >
                        <Eye className="w-3.5 h-3.5" />
                        <span>Inspect</span>
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Log Details Modal */}
      {selectedLog && (
        <Modal
          isOpen={!!selectedLog}
          onClose={() => setSelectedLog(null)}
          title={`Audit Record: ${selectedLog.action}`}
          subtitle={`Log ID: ${selectedLog.id}`}
          maxWidth="md"
        >
          <div className="space-y-4 text-xs">
            <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 space-y-2">
              <div className="flex justify-between">
                <span className="text-slate-500">Administrator UID/Email:</span>
                <span className="text-white font-mono">{selectedLog.adminEmail}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Target Entity:</span>
                <span className="text-white font-mono">{selectedLog.targetType} / {selectedLog.targetId}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Logged Timestamp:</span>
                <span className="text-white font-mono">{new Date(selectedLog.timestamp).toISOString()}</span>
              </div>
            </div>

            <div>
              <span className="font-semibold text-slate-300 block mb-1">Human-Readable Summary:</span>
              <p className="p-3 bg-slate-950 rounded-xl border border-slate-800 text-slate-200 leading-relaxed">
                {selectedLog.summary}
              </p>
            </div>

            {selectedLog.details && (
              <div>
                <span className="font-semibold text-slate-300 block mb-1">Audit Metadata Diff:</span>
                <pre className="p-3 bg-slate-950 rounded-xl border border-slate-800 text-[11px] font-mono text-indigo-300 overflow-x-auto leading-relaxed">
                  {JSON.stringify(selectedLog.details, null, 2)}
                </pre>
              </div>
            )}

            <div className="pt-2 flex justify-end">
              <button
                type="button"
                onClick={() => setSelectedLog(null)}
                className="px-4 py-2 text-xs font-semibold text-white bg-slate-800 hover:bg-slate-700 rounded-lg"
              >
                Close Record
              </button>
            </div>
          </div>
        </Modal>
      )}
    </div>
  );
};
