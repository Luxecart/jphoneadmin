import React, { useState } from 'react';
import { AppSettings } from '../types';
import { 
  Smartphone, 
  Save, 
  Check, 
  AlertTriangle, 
  Download, 
  ShieldAlert, 
  ExternalLink,
  Code2
} from 'lucide-react';

interface AppUpdatePageProps {
  settings: AppSettings;
  onSaveSettings: (settings: AppSettings) => Promise<void>;
}

export const AppUpdatePage: React.FC<AppUpdatePageProps> = ({
  settings,
  onSaveSettings
}) => {
  const [minVersion, setMinVersion] = useState(settings.minSupportedVersion || '1.2.0');
  const [latestVersion, setLatestVersion] = useState(settings.latestVersion || '1.4.2');
  const [downloadUrl, setDownloadUrl] = useState(
    settings.downloadUrl || 'https://play.google.com/store/apps/details?id=com.aistudio.jphone.qkzvtb'
  );
  const [forceUpdate, setForceUpdate] = useState(settings.forceUpdate);
  const [isSaving, setIsSaving] = useState(false);
  const [savedSuccess, setSavedSuccess] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSaving(true);
    try {
      await onSaveSettings({
        ...settings,
        minSupportedVersion: minVersion.trim(),
        latestVersion: latestVersion.trim(),
        downloadUrl: downloadUrl.trim(),
        forceUpdate
      });
      setSavedSuccess(true);
      setTimeout(() => setSavedSuccess(false), 2500);
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-white flex items-center gap-2">
            <Smartphone className="w-5 h-5 text-indigo-400" />
            <span>App Update &amp; Release Management</span>
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Control minimum supported build numbers, Play Store redirects, and mandatory upgrade enforcement for JPhone Android.
          </p>
        </div>

        {savedSuccess && (
          <span className="text-xs font-semibold text-emerald-400 bg-emerald-500/10 px-3 py-1.5 rounded-lg border border-emerald-500/30 flex items-center gap-1.5 animate-fadeIn">
            <Check className="w-4 h-4" /> Release Rules Published
          </span>
        )}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Release Version Controls Form */}
        <div className="glass-panel p-5 lg:col-span-2 space-y-4">
          <h3 className="text-sm font-bold text-white">Version Enforcement Matrix</h3>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Minimum Supported Version Code <span className="text-rose-400">*</span>
                </label>
                <input
                  type="text"
                  required
                  value={minVersion}
                  onChange={(e) => setMinVersion(e.target.value)}
                  placeholder="e.g. 1.2.0"
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs font-mono text-white placeholder-slate-600 focus:outline-none focus:border-indigo-500"
                />
                <p className="text-[11px] text-slate-500 mt-1">Clients running below this version will be blocked from logging in.</p>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Latest Public Version Code <span className="text-rose-400">*</span>
                </label>
                <input
                  type="text"
                  required
                  value={latestVersion}
                  onChange={(e) => setLatestVersion(e.target.value)}
                  placeholder="e.g. 1.4.2"
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs font-mono text-white placeholder-slate-600 focus:outline-none focus:border-indigo-500"
                />
                <p className="text-[11px] text-slate-500 mt-1">Prompted to users running an older build.</p>
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Official Google Play Store / Download URL <span className="text-rose-400">*</span>
              </label>
              <input
                type="url"
                required
                value={downloadUrl}
                onChange={(e) => setDownloadUrl(e.target.value)}
                placeholder="https://play.google.com/store/apps/details?id=com.aistudio.jphone.qkzvtb"
                className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs font-mono text-white placeholder-slate-600 focus:outline-none focus:border-indigo-500"
              />
            </div>

            {/* Force Update Toggle */}
            <div className="flex items-center justify-between p-3.5 bg-slate-950 rounded-xl border border-slate-800">
              <div>
                <span className="font-semibold text-white text-xs block">Enforce Mandatory Upgrade (Force Update)</span>
                <span className="text-slate-400 text-[11px] block mt-0.5">
                  When enabled, users with outdated builds cannot dismiss the update dialog.
                </span>
              </div>
              <input
                type="checkbox"
                checked={forceUpdate}
                onChange={(e) => setForceUpdate(e.target.checked)}
                className="w-4 h-4 text-indigo-600 rounded bg-slate-900 border-slate-700 focus:ring-indigo-500 cursor-pointer"
              />
            </div>

            <div className="pt-2 flex justify-end">
              <button
                type="submit"
                disabled={isSaving}
                className="px-5 py-2.5 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-500 rounded-xl shadow-lg shadow-indigo-900/30 flex items-center gap-2 transition-colors"
              >
                <Save className="w-4 h-4" />
                <span>{isSaving ? 'Saving...' : 'Deploy Version Matrix'}</span>
              </button>
            </div>
          </form>
        </div>

        {/* Client Implementation Guide */}
        <div className="glass-panel p-5 space-y-4">
          <h3 className="text-sm font-bold text-white flex items-center gap-2">
            <Code2 className="w-4 h-4 text-indigo-400" />
            <span>Android In-App Update Logic</span>
          </h3>

          <p className="text-xs text-slate-400 leading-relaxed">
            The JPhone Android client queries the remote version document on launch. If the local <code className="text-indigo-300 font-mono">BuildConfig.VERSION_NAME</code> is strictly less than <code className="text-indigo-300 font-mono">min_supported_version</code>:
          </p>

          <pre className="p-3 bg-slate-950 rounded-xl border border-slate-800 text-[10px] font-mono text-slate-300 overflow-x-auto leading-relaxed">
{`val currentVer = BuildConfig.VERSION_NAME
if (isVersionLower(currentVer, remoteMinVer)) {
    // Show non-dismissible AlertDialog
    showForceUpdateDialog(downloadUrl)
} else if (isVersionLower(currentVer, latestVer)) {
    // Optional banner or Google Play In-App Update
    promptFlexibleUpdate()
}`}
          </pre>

          <div className="p-3 rounded-xl bg-slate-950 border border-slate-800/80 text-[11px] text-slate-400 flex items-start gap-2">
            <ShieldAlert className="w-4 h-4 text-indigo-400 shrink-0 mt-0.5" />
            <span>Never bypass Android package manager validation or download unverified APKs outside Google Play.</span>
          </div>
        </div>
      </div>
    </div>
  );
};
