import React, { useState } from 'react';
import { AppSettings } from '../types';
import { generateAndroidRemoteConfigJson } from '../services/settingsService';
import { 
  Settings, 
  Save, 
  ShieldAlert, 
  Copy, 
  Check, 
  Smartphone, 
  AlertTriangle,
  Code2,
  FileJson
} from 'lucide-react';

interface SettingsPageProps {
  settings: AppSettings;
  onSaveSettings: (settings: AppSettings) => Promise<void>;
}

export const SettingsPage: React.FC<SettingsPageProps> = ({
  settings,
  onSaveSettings
}) => {
  const [formData, setFormData] = useState<AppSettings>({ ...settings });
  const [isSaving, setIsSaving] = useState(false);
  const [copied, setCopied] = useState(false);
  const [saveMessage, setSaveMessage] = useState(false);

  // Sync if prop changes
  React.useEffect(() => {
    setFormData({ ...settings });
  }, [settings]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSaving(true);
    try {
      await onSaveSettings(formData);
      setSaveMessage(true);
      setTimeout(() => setSaveMessage(false), 3000);
    } finally {
      setIsSaving(false);
    }
  };

  const remoteJson = generateAndroidRemoteConfigJson(formData);

  const handleCopyJson = () => {
    navigator.clipboard.writeText(remoteJson);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-white flex items-center gap-2">
            <Settings className="w-5 h-5 text-indigo-400" />
            <span>Remote App Settings</span>
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Global operational parameters consumed dynamically by the JPhone Android application via Cloud Firestore.
          </p>
        </div>

        {saveMessage && (
          <span className="text-xs font-semibold text-emerald-400 bg-emerald-500/10 px-3 py-1.5 rounded-lg border border-emerald-500/30 flex items-center gap-1.5 animate-fadeIn">
            <Check className="w-4 h-4" /> Remote Settings Saved &amp; Synced
          </span>
        )}
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        {/* General Application Configuration */}
        <div className="glass-panel p-5 space-y-4">
          <h3 className="text-sm font-bold text-white flex items-center gap-2">
            <Smartphone className="w-4 h-4 text-indigo-400" />
            <span>General Application Identity</span>
          </h3>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Application Brand Name
              </label>
              <input
                type="text"
                required
                value={formData.appName}
                onChange={(e) => setFormData({ ...formData, appName: e.target.value })}
                className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white placeholder-slate-600 focus:outline-none focus:border-indigo-500"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Official Customer Support Email
              </label>
              <input
                type="email"
                required
                value={formData.supportEmail}
                onChange={(e) => setFormData({ ...formData, supportEmail: e.target.value })}
                className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white placeholder-slate-600 focus:outline-none focus:border-indigo-500"
              />
            </div>
          </div>
        </div>

        {/* Maintenance Mode Configuration */}
        <div className="glass-panel p-5 space-y-4 border-amber-500/20">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <ShieldAlert className="w-4 h-4 text-amber-400" />
              <span>Maintenance Mode Safeguards</span>
            </h3>

            <div className="flex items-center gap-2">
              <span className={`text-xs font-mono font-semibold px-2 py-0.5 rounded border ${
                formData.maintenanceMode
                  ? 'bg-rose-500/10 text-rose-400 border-rose-500/30'
                  : 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30'
              }`}>
                {formData.maintenanceMode ? 'ACTIVE (APP LOCKED)' : 'INACTIVE (NORMAL)'}
              </span>
            </div>
          </div>

          <p className="text-xs text-slate-400 leading-relaxed">
            When enabled, the JPhone Android application presents a non-dismissible maintenance dialog, preventing end-user database queries while backend migrations or security audits take place.
          </p>

          <div className="flex items-center gap-3 p-3 bg-slate-950 rounded-xl border border-slate-800">
            <input
              type="checkbox"
              id="maintToggle"
              checked={formData.maintenanceMode}
              onChange={(e) => setFormData({ ...formData, maintenanceMode: e.target.checked })}
              className="w-4 h-4 text-rose-600 rounded bg-slate-900 border-slate-700 focus:ring-rose-500"
            />
            <label htmlFor="maintToggle" className="text-xs text-slate-300 cursor-pointer">
              <span className="font-semibold text-white">Enable Maintenance Mode Globally</span>
              <span className="block text-slate-400 text-[11px]">Directs all Android clients to the maintenance screen.</span>
            </label>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Emergency Bypass Secret Key
              </label>
              <input
                type="text"
                required
                value={formData.maintenanceBypassKey}
                onChange={(e) => setFormData({ ...formData, maintenanceBypassKey: e.target.value })}
                placeholder="e.g. dev_bypass_token_2026"
                className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs font-mono text-white placeholder-slate-600 focus:outline-none focus:border-indigo-500"
              />
              <p className="text-[11px] text-slate-500 mt-1">Allows QA and developers to bypass the maintenance screen by tapping the logo 5 times.</p>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                User-Facing Maintenance Message
              </label>
              <input
                type="text"
                required
                value={formData.maintenanceMessage}
                onChange={(e) => setFormData({ ...formData, maintenanceMessage: e.target.value })}
                className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white placeholder-slate-600 focus:outline-none focus:border-indigo-500"
              />
            </div>
          </div>
        </div>

        {/* Action Button */}
        <div className="flex justify-end">
          <button
            type="submit"
            disabled={isSaving}
            className="px-5 py-2.5 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-500 rounded-xl shadow-lg shadow-indigo-900/30 flex items-center gap-2 transition-colors"
          >
            <Save className="w-4 h-4" />
            <span>{isSaving ? 'Deploying Changes...' : 'Save & Publish Remote Config'}</span>
          </button>
        </div>
      </form>

      {/* Android Sync Schema Viewer */}
      <div className="glass-panel p-5 space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2 text-sm font-bold text-white">
            <FileJson className="w-4 h-4 text-indigo-400" />
            <span>Android Remote Config JSON Export</span>
          </div>

          <button
            type="button"
            onClick={handleCopyJson}
            className="px-3 py-1.5 text-xs font-semibold text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 rounded-lg flex items-center gap-1.5 transition-colors font-mono"
          >
            {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
            <span>{copied ? 'Copied' : 'Copy JSON'}</span>
          </button>
        </div>

        <pre className="p-4 bg-slate-950 rounded-xl border border-slate-800 text-[11px] font-mono text-slate-300 overflow-x-auto max-h-60 leading-relaxed">
          {remoteJson}
        </pre>
      </div>
    </div>
  );
};
