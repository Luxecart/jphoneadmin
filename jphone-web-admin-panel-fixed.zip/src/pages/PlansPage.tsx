import React, { useState } from 'react';
import { Plan } from '../types';
import { PlanEditorModal } from '../components/plans/PlanEditorModal';
import { 
  CreditCard, 
  Plus, 
  Check, 
  Clock, 
  Edit3, 
  DollarSign, 
  ShieldCheck, 
  AlertCircle,
  ToggleLeft,
  ToggleRight,
  ExternalLink
} from 'lucide-react';

interface PlansPageProps {
  plans: Plan[];
  onSavePlan: (plan: Plan, isNew: boolean) => Promise<void>;
  onToggleActive: (planId: string, isActive: boolean) => Promise<void>;
}

export const PlansPage: React.FC<PlansPageProps> = ({
  plans,
  onSavePlan,
  onToggleActive
}) => {
  const [selectedPlan, setSelectedPlan] = useState<Plan | null>(null);
  const [isEditorOpen, setIsEditorOpen] = useState(false);

  const handleOpenCreate = () => {
    setSelectedPlan(null);
    setIsEditorOpen(true);
  };

  const handleOpenEdit = (plan: Plan) => {
    setSelectedPlan(plan);
    setIsEditorOpen(true);
  };

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-white flex items-center gap-2">
            <CreditCard className="w-5 h-5 text-indigo-400" />
            <span>Membership &amp; Subscription Plans</span>
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Configure premium tier definitions, SKUs, duration, and feature access available to JPhone users.
          </p>
        </div>

        <button
          onClick={handleOpenCreate}
          className="px-4 py-2 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-500 rounded-xl flex items-center gap-1.5 shadow-lg shadow-indigo-900/30 transition-colors"
        >
          <Plus className="w-4 h-4" />
          <span>New Subscription Plan</span>
        </button>
      </div>

      {/* Payment Gateway & Google Play Notice Banner */}
      <div className="p-4 rounded-xl bg-slate-900/80 border border-slate-800 text-xs text-slate-300 space-y-2">
        <div className="flex items-center gap-2 font-bold text-white">
          <AlertCircle className="w-4 h-4 text-amber-400" />
          <span>Payment Provider Architecture Status: Integration Pending</span>
        </div>
        <p className="leading-relaxed text-slate-400">
          In compliance with the Zero-Fraud Payment Specification, purchases are never marked as verified based merely on client-side requests. Real digital subscriptions on Android must integrate Google Play Billing Library (<code className="text-indigo-300 font-mono">com.android.billingclient:billing</code>) with server-side receipt validation via the Google Play Developer API. Current checkout metrics and transactions are clearly flagged as pending server verification.
        </p>
      </div>

      {/* Plans Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {plans.map((plan) => (
          <div
            key={plan.id}
            className={`glass-panel p-6 flex flex-col justify-between relative transition-all duration-200 ${
              plan.isActive ? 'border-slate-800 hover:border-slate-700' : 'opacity-65 border-dashed border-slate-800'
            }`}
          >
            <div>
              {/* Top Header */}
              <div className="flex items-start justify-between mb-3">
                <span className={`text-[10px] font-mono uppercase px-2 py-0.5 rounded font-bold border ${
                  plan.isActive 
                    ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30' 
                    : 'bg-slate-800 text-slate-400 border-slate-700'
                }`}>
                  {plan.isActive ? 'Live for Checkout' : 'Disabled'}
                </span>
                <span className="text-[11px] font-mono text-slate-500">
                  {plan.code}
                </span>
              </div>

              {/* Title & Price */}
              <h3 className="text-lg font-bold text-white tracking-tight">{plan.name}</h3>
              <p className="text-xs text-slate-400 mt-1 min-h-[32px]">{plan.description}</p>

              <div className="my-5 pb-5 border-b border-slate-800 flex items-baseline gap-1.5">
                <span className="text-3xl font-extrabold text-white font-mono">
                  ${plan.price.toFixed(2)}
                </span>
                <span className="text-xs text-slate-400 font-medium">
                  / {plan.durationDays >= 3650 ? 'Lifetime' : `${plan.durationDays} days`}
                </span>
              </div>

              {/* Feature Checklist */}
              <div className="space-y-2 mb-6">
                <div className="text-[11px] font-bold uppercase tracking-wider text-slate-500">
                  Included Privileges
                </div>
                {plan.features.map((feat, idx) => (
                  <div key={idx} className="flex items-start gap-2 text-xs text-slate-300">
                    <Check className="w-3.5 h-3.5 text-indigo-400 shrink-0 mt-0.5" />
                    <span>{feat}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Bottom Controls */}
            <div className="pt-4 border-t border-slate-800 flex items-center justify-between">
              <button
                onClick={() => onToggleActive(plan.id, !plan.isActive)}
                className={`text-xs font-semibold flex items-center gap-1.5 transition-colors ${
                  plan.isActive ? 'text-amber-400 hover:text-amber-300' : 'text-emerald-400 hover:text-emerald-300'
                }`}
              >
                {plan.isActive ? (
                  <>
                    <ToggleRight className="w-5 h-5" />
                    <span>Disable</span>
                  </>
                ) : (
                  <>
                    <ToggleLeft className="w-5 h-5 text-slate-500" />
                    <span>Enable</span>
                  </>
                )}
              </button>

              <button
                onClick={() => handleOpenEdit(plan)}
                className="px-3 py-1.5 text-xs font-semibold text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 rounded-lg flex items-center gap-1.5 transition-colors"
              >
                <Edit3 className="w-3.5 h-3.5" />
                <span>Edit</span>
              </button>
            </div>
          </div>
        ))}
      </div>

      <PlanEditorModal
        isOpen={isEditorOpen}
        plan={selectedPlan}
        onClose={() => setIsEditorOpen(false)}
        onSave={onSavePlan}
      />
    </div>
  );
};
