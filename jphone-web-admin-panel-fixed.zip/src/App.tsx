import React, { useState, useEffect, useCallback } from 'react';
import { 
  JPhoneUser, 
  Plan, 
  AppSettings, 
  PushNotification, 
  AuditLog,
  SubscriptionTier 
} from './types';
import { 
  fetchUsers, 
  updateUserSuspension, 
  updateUserSubscriptionTier, 
  updateUserNotes 
} from './services/userService';
import { fetchPlans, savePlan, togglePlanActive } from './services/planService';
import { fetchAppSettings, saveAppSettings } from './services/settingsService';
import { fetchNotifications, sendBroadcastNotification } from './services/notificationService';
import { fetchAuditLogs, recordAuditLog } from './services/auditService';
import { getStoredFirebaseConfig, auth, subscribeAuth, checkIsAdmin } from './services/firebase';
import LoginScreen from './components/auth/LoginScreen';

// Layout & UI Components
import { Header } from './components/layout/Header';
import { Sidebar } from './components/layout/Sidebar';
import { UserDetailModal } from './components/users/UserDetailModal';
import { SuspendModal } from './components/users/SuspendModal';
import { GrantPremiumModal } from './components/users/GrantPremiumModal';

// Pages
import { DashboardPage } from './pages/DashboardPage';
import { UsersPage } from './pages/UsersPage';
import { PlansPage } from './pages/PlansPage';
import { SettingsPage } from './pages/SettingsPage';
import { WhatsAppPage } from './pages/WhatsAppPage';
import { AdsPage } from './pages/AdsPage';
import { NotificationsPage } from './pages/NotificationsPage';
import { AppUpdatePage } from './pages/AppUpdatePage';
import { DiagnosticsPage } from './pages/DiagnosticsPage';
import { AuditLogsPage } from './pages/AuditLogsPage';
import { SetupGuidePage } from './pages/SetupGuidePage';

// Fallback initial settings
import { INITIAL_MOCK_SETTINGS } from './services/mockData';

export default function App() {
  // Auth gate: Firebase configured ho to Google login + admin check lazmi hai.
  // Config na ho to sirf SANDBOX preview (demo data) chalta hai.
  const [authState, setAuthState] = useState<'loading' | 'signed_out' | 'denied' | 'admin' | 'sandbox'>(
    auth ? 'loading' : 'sandbox'
  );
  const [currentPage, setCurrentPage] = useState<string>('dashboard');
  const [isMobileNavOpen, setIsMobileNavOpen] = useState(false);
  
  // Data state
  const [users, setUsers] = useState<JPhoneUser[]>([]);
  const [plans, setPlans] = useState<Plan[]>([]);
  const [settings, setSettings] = useState<AppSettings>(INITIAL_MOCK_SETTINGS);
  const [notifications, setNotifications] = useState<PushNotification[]>([]);
  const [auditLogs, setAuditLogs] = useState<AuditLog[]>([]);
  const [isLiveDatabase, setIsLiveDatabase] = useState(false);
  const [isLoading, setIsLoading] = useState(true);

  // Modals state
  const [detailUser, setDetailUser] = useState<JPhoneUser | null>(null);
  const [suspendUser, setSuspendUser] = useState<JPhoneUser | null>(null);
  const [grantPremiumUser, setGrantPremiumUser] = useState<JPhoneUser | null>(null);

  const loadAllData = useCallback(async () => {
    setIsLoading(true);
    try {
      const [uRes, pRes, sRes, nRes, aRes] = await Promise.all([
        fetchUsers(),
        fetchPlans(),
        fetchAppSettings(),
        fetchNotifications(),
        fetchAuditLogs()
      ]);

      setUsers(uRes.users);
      setIsLiveDatabase(uRes.isLive);
      setPlans(pRes.plans);
      setSettings(sRes.settings);
      setNotifications(nRes.notifications);
      setAuditLogs(aRes.logs);
    } catch (err) {
      console.error('Error loading admin panel records:', err);
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    if (!auth) return;
    return subscribeAuth(async (user) => {
      if (!user) { setAuthState('signed_out'); return; }
      setAuthState('loading');
      setAuthState((await checkIsAdmin(user)) ? 'admin' : 'denied');
    });
  }, []);

  useEffect(() => {
    if (authState === 'admin' || authState === 'sandbox') loadAllData();
  }, [authState, loadAllData]);

  // User Actions
  const handleConfirmSuspend = async (reason: string) => {
    if (!suspendUser) return;
    const isSuspending = !suspendUser.isSuspended;
    await updateUserSuspension(suspendUser.id, isSuspending, reason);
    await loadAllData();
  };

  const handleConfirmGrantPremium = async (tier: SubscriptionTier, durationDays: number, reason: string) => {
    if (!grantPremiumUser) return;
    await updateUserSubscriptionTier(grantPremiumUser.id, tier, durationDays, reason);
    await loadAllData();
  };

  const handleSaveNotes = async (userId: string, notes: string) => {
    await updateUserNotes(userId, notes);
    setUsers(prev => prev.map(u => u.id === userId ? { ...u, adminNotes: notes } : u));
    if (detailUser && detailUser.id === userId) {
      setDetailUser({ ...detailUser, adminNotes: notes });
    }
  };

  // Plan Actions
  const handleSavePlan = async (plan: Plan, isNew: boolean) => {
    await savePlan(plan, isNew);
    await loadAllData();
  };

  const handleTogglePlanActive = async (planId: string, isActive: boolean) => {
    await togglePlanActive(planId, isActive);
    await loadAllData();
  };

  // Settings Actions
  const handleSaveSettings = async (updated: AppSettings) => {
    await saveAppSettings(updated);
    setSettings(updated);
  };

  // Push Notification Dispatch
  const handleSendNotification = async (notifData: any) => {
    const result = await sendBroadcastNotification(notifData);
    await loadAllData();
    return result;
  };

  if (authState === 'loading' || authState === 'signed_out' || authState === 'denied') {
    return <LoginScreen state={authState} />;
  }

  return (
    <div className="flex min-h-screen bg-slate-950 text-slate-100 font-sans selection:bg-indigo-500 selection:text-white">
      {/* Sidebar Navigation */}
      <Sidebar
        currentPage={currentPage}
        onNavigate={setCurrentPage}
        isMobileOpen={isMobileNavOpen}
        onCloseMobile={() => setIsMobileNavOpen(false)}
      />

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col min-w-0">
        {/* Top Header */}
        <Header
          onOpenMobileNav={() => setIsMobileNavOpen(true)}
          onNavigate={setCurrentPage}
          currentPage={currentPage}
        />

        {/* Page View Container */}
        <main className="flex-1 p-4 md:p-8 max-w-7xl w-full mx-auto">
          {isLoading && users.length === 0 ? (
            <div className="flex flex-col items-center justify-center min-h-[50vh] space-y-3">
              <div className="w-8 h-8 border-2 border-indigo-500 border-t-transparent rounded-full animate-spin" />
              <div className="text-xs text-slate-400 font-mono">Synchronizing JPhone Records...</div>
            </div>
          ) : (
            <>
              {currentPage === 'dashboard' && (
                <DashboardPage
                  users={users}
                  plans={plans}
                  notifications={notifications}
                  auditLogs={auditLogs}
                  onNavigate={setCurrentPage}
                  onSelectUser={(u) => setDetailUser(u)}
                />
              )}

              {currentPage === 'users' && (
                <UsersPage
                  users={users}
                  onRefresh={loadAllData}
                  onSelectUser={(u) => setDetailUser(u)}
                  onOpenSuspend={(u) => setSuspendUser(u)}
                  onOpenGrantPremium={(u) => setGrantPremiumUser(u)}
                  isLive={isLiveDatabase}
                />
              )}

              {currentPage === 'plans' && (
                <PlansPage
                  plans={plans}
                  onSavePlan={handleSavePlan}
                  onToggleActive={handleTogglePlanActive}
                />
              )}

              {currentPage === 'settings' && (
                <SettingsPage
                  settings={settings}
                  onSaveSettings={handleSaveSettings}
                />
              )}

              {currentPage === 'whatsapp' && (
                <WhatsAppPage
                  settings={settings}
                  onSaveSettings={handleSaveSettings}
                />
              )}

              {currentPage === 'ads' && (
                <AdsPage
                  settings={settings}
                  onSaveSettings={handleSaveSettings}
                />
              )}

              {currentPage === 'notifications' && (
                <NotificationsPage
                  notifications={notifications}
                  onSendNotification={handleSendNotification}
                />
              )}

              {currentPage === 'app-update' && (
                <AppUpdatePage
                  settings={settings}
                  onSaveSettings={handleSaveSettings}
                />
              )}

              {currentPage === 'diagnostics' && (
                <DiagnosticsPage />
              )}

              {currentPage === 'audit-logs' && (
                <AuditLogsPage auditLogs={auditLogs} />
              )}

              {currentPage === 'setup-guide' && (
                <SetupGuidePage />
              )}
            </>
          )}
        </main>
      </div>

      {/* User Modals */}
      <UserDetailModal
        isOpen={!!detailUser}
        user={detailUser}
        onClose={() => setDetailUser(null)}
        onOpenSuspend={(u) => {
          setSuspendUser(u);
          setDetailUser(null);
        }}
        onOpenGrantPremium={(u) => {
          setGrantPremiumUser(u);
          setDetailUser(null);
        }}
        onSaveNotes={handleSaveNotes}
      />

      <SuspendModal
        isOpen={!!suspendUser}
        user={suspendUser}
        onClose={() => setSuspendUser(null)}
        onConfirm={handleConfirmSuspend}
      />

      <GrantPremiumModal
        isOpen={!!grantPremiumUser}
        user={grantPremiumUser}
        onClose={() => setGrantPremiumUser(null)}
        onConfirm={handleConfirmGrantPremium}
      />
    </div>
  );
}
