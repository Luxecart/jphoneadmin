export type SubscriptionTier = 'free' | 'premium';

export interface JPhoneUser {
  id: string;
  email?: string;
  emailVerified: boolean;
  phoneNumber?: string;
  phoneVerified: boolean;
  displayName?: string;
  subscriptionTier: SubscriptionTier;
  subscriptionExpiry?: string | null;
  isSuspended: boolean;
  suspendedReason?: string;
  createdAt: string;
  lastSeenAt?: string;
  adminNotes?: string;
}

export interface AdminUser {
  id: string;
  email: string;
  role: 'super_admin' | 'admin' | 'moderator';
  assignedBy: string;
  assignedAt: string;
  active: boolean;
}

export interface Plan {
  id: string;
  name: string;
  code: string;
  price: number;
  currency: string;
  durationDays: number;
  description: string;
  features: string[];
  isActive: boolean;
  updatedAt: string;
  updatedBy: string;
}

export interface Subscription {
  id: string;
  userId: string;
  userEmail?: string;
  planId: string;
  planName?: string;
  status: 'active' | 'expired' | 'revoked' | 'pending_verification';
  tier: SubscriptionTier;
  startDate: string;
  expiryDate: string;
  grantReason?: string;
  grantedByAdminId?: string;
  paymentMethod: 'google_play' | 'stripe' | 'complimentary' | 'manual';
  paymentStatus: 'verified' | 'pending' | 'failed' | 'complimentary';
  createdAt: string;
}

export interface AppSettings {
  id?: string;
  appName: string;
  supportEmail: string;
  supportPhoneWhatsApp: string;
  whatsAppEnabled: boolean;
  whatsAppDefaultMessage: string;
  maintenanceMode: boolean;
  maintenanceBypassKey: string;
  maintenanceMessage: string;
  minSupportedVersion: string;
  latestVersion: string;
  downloadUrl: string;
  forceUpdate: boolean;
  // Ads settings
  adsEnabled: boolean;
  testAdsMode: boolean;
  adMobAppId: string;
  adMobBannerId: string;
  adMobInterstitialId: string;
  adMobRewardedId: string;
  appLovinKey: string;
  unityGameId: string;
  updatedAt: string;
  updatedBy: string;
}

export interface PushNotification {
  id: string;
  title: string;
  body: string;
  imageUrl?: string;
  targetAudience: 'all' | 'free_users' | 'premium_users' | 'topic_announcements';
  deepLink?: string;
  sentAt: string;
  sentByAdminId: string;
  status: 'sent' | 'scheduled' | 'draft' | 'failed';
  deliveryCount?: number;
}

export interface AuditLog {
  id: string;
  adminId: string;
  adminEmail: string;
  action: 'LOGIN' | 'USER_SUSPENDED' | 'USER_REACTIVATED' | 'PREMIUM_GRANTED' | 'PREMIUM_REVOKED' | 'PLAN_CREATED' | 'PLAN_UPDATED' | 'SETTINGS_UPDATED' | 'NOTIFICATION_BROADCAST' | 'UPDATE_RELEASED';
  targetType: 'user' | 'plan' | 'settings' | 'notification' | 'auth';
  targetId: string;
  summary: string;
  timestamp: string;
  details?: Record<string, unknown>;
}

export interface DiagnosticCheck {
  id: string;
  name: string;
  category: 'Firebase' | 'Auth' | 'Android' | 'Security';
  status: 'success' | 'warning' | 'error' | 'pending';
  summary: string;
  details: string;
  recommendation?: string;
  docsUrl?: string;
}
