import { Plan } from '../types';
import { INITIAL_MOCK_PLANS } from './mockData';
import { db, auth, handleFirestoreError, OperationType } from './firebase';
import { collection, getDocs, doc, setDoc, updateDoc } from 'firebase/firestore';
import { recordAuditLog } from './auditService';
import { toIso, clean } from './utils';

let inMemoryPlans: Plan[] = [...INITIAL_MOCK_PLANS];
const isLive = () => !!(db && auth?.currentUser);

// Android app collection: /premium_plans/{planId}
// Android fields: name, durationDays, priceDisplay, isEnabled, benefits[], isPopular, updatedAt(millis)
function mapPlan(id: string, d: any): Plan {
  const parsedPrice = parseFloat(String(d.priceDisplay ?? '').replace(/[^0-9.]/g, ''));
  return {
    id,
    name: d.name ?? id,
    code: d.code ?? id.toUpperCase(),
    price: typeof d.price === 'number' ? d.price : (isNaN(parsedPrice) ? 0 : parsedPrice),
    currency: d.currency ?? 'USD',
    durationDays: Number(d.durationDays) || 30,
    description: d.description ?? '',
    features: Array.isArray(d.features) ? d.features : Array.isArray(d.benefits) ? d.benefits : [],
    isActive: d.isEnabled ?? d.isActive ?? true,
    updatedAt: toIso(d.updatedAt) ?? '',
    updatedBy: d.updatedBy ?? ''
  };
}

export async function fetchPlans(): Promise<{ plans: Plan[]; isLive: boolean }> {
  if (isLive()) {
    try {
      const snap = await getDocs(collection(db!, 'premium_plans'));
      return { plans: snap.docs.map(d => mapPlan(d.id, d.data())), isLive: true };
    } catch (err) {
      console.error('Plans fetch failed:', err);
      return { plans: [], isLive: true };
    }
  }
  return { plans: inMemoryPlans, isLive: false };
}

export async function savePlan(plan: Plan, isNew: boolean): Promise<void> {
  const adminEmail = auth?.currentUser?.email || 'admin@jphone.app';
  const adminId = auth?.currentUser?.uid || 'admin_sys';
  const updatedPlan: Plan = { ...plan, updatedAt: new Date().toISOString(), updatedBy: adminEmail };

  if (isLive()) {
    try {
      await setDoc(doc(db!, 'premium_plans', plan.id), clean({
        id: plan.id,
        name: plan.name,
        code: plan.code,
        price: plan.price,
        currency: plan.currency,
        priceDisplay: `${plan.currency} ${plan.price}`,
        durationDays: plan.durationDays,
        description: plan.description,
        features: plan.features,
        benefits: plan.features,
        isEnabled: plan.isActive,
        isActive: plan.isActive,
        updatedAt: Date.now(),
        updatedBy: adminEmail
      }), { merge: true });
    } catch (err) {
      handleFirestoreError(err, isNew ? OperationType.CREATE : OperationType.UPDATE, `premium_plans/${plan.id}`);
    }
  } else if (isNew) {
    inMemoryPlans = [...inMemoryPlans, updatedPlan];
  } else {
    inMemoryPlans = inMemoryPlans.map(p => p.id === plan.id ? updatedPlan : p);
  }

  await recordAuditLog({
    adminId, adminEmail,
    action: isNew ? 'PLAN_CREATED' : 'PLAN_UPDATED',
    targetType: 'plan', targetId: plan.id,
    summary: isNew ? `Created new pricing plan "${plan.name}"` : `Updated pricing plan "${plan.name}" (${plan.currency} ${plan.price})`,
    details: { plan: updatedPlan }
  });
}

export async function togglePlanActive(planId: string, isActive: boolean): Promise<void> {
  const adminEmail = auth?.currentUser?.email || 'admin@jphone.app';
  const adminId = auth?.currentUser?.uid || 'admin_sys';

  if (isLive()) {
    try {
      await updateDoc(doc(db!, 'premium_plans', planId), { isEnabled: isActive, isActive, updatedAt: Date.now(), updatedBy: adminEmail });
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `premium_plans/${planId}`);
    }
    await recordAuditLog({
      adminId, adminEmail, action: 'PLAN_UPDATED', targetType: 'plan', targetId: planId,
      summary: `Plan ${isActive ? 'enabled' : 'disabled'}`, details: { isActive }
    });
    return;
  }
  const target = inMemoryPlans.find(p => p.id === planId);
  if (target) await savePlan({ ...target, isActive }, false);
}
