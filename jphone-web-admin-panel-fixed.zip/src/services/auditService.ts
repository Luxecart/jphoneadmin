import { AuditLog } from '../types';
import { INITIAL_MOCK_AUDIT_LOGS } from './mockData';
import { db, auth } from './firebase';
import { collection, getDocs, doc, setDoc, query, orderBy, limit } from 'firebase/firestore';
import { clean } from './utils';

let inMemoryAuditLogs: AuditLog[] = [...INITIAL_MOCK_AUDIT_LOGS];

// Android app ke Firestore rules ka collection: /admin_audit_logs
const COL = 'admin_audit_logs';

export async function fetchAuditLogs(): Promise<{ logs: AuditLog[]; isLive: boolean }> {
  if (db && auth?.currentUser) {
    try {
      const q = query(collection(db, COL), orderBy('timestamp', 'desc'), limit(50));
      const snap = await getDocs(q);
      return { logs: snap.docs.map(d => ({ ...(d.data() as AuditLog), id: d.id })), isLive: true };
    } catch (err) {
      console.error('Audit logs fetch failed:', err);
      return { logs: [], isLive: true };
    }
  }
  return { logs: inMemoryAuditLogs, isLive: false };
}

export async function recordAuditLog(entry: Omit<AuditLog, 'id' | 'timestamp'>): Promise<AuditLog> {
  const id = `log_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`;
  const timestamp = new Date().toISOString();
  const logItem: AuditLog = { ...entry, id, timestamp };

  if (db && auth?.currentUser) {
    try {
      // Rules: adminUid == request.auth.uid aur action/targetId/timestamp zaroori
      await setDoc(doc(db, COL, id), clean({ ...logItem, adminUid: auth.currentUser.uid }));
    } catch (err) {
      console.error('Audit log write error:', err);
    }
  } else {
    inMemoryAuditLogs = [logItem, ...inMemoryAuditLogs];
  }
  return logItem;
}
