import { DiagnosticCheck } from '../types';
import { getStoredFirebaseConfig, testFirestoreConnection, auth } from './firebase';

export interface ConfigurationNotFoundCause {
  code: string;
  title: string;
  severity: 'CRITICAL' | 'HIGH' | 'MEDIUM';
  description: string;
  exactResolution: string[];
  firebaseConsolePath: string;
  androidImpact: string;
}

export const CONFIGURATION_NOT_FOUND_ANALYSIS: ConfigurationNotFoundCause[] = [
  {
    code: 'PHONE_PROVIDER_DISABLED',
    title: 'Phone Authentication Provider Not Enabled in Firebase Console',
    severity: 'CRITICAL',
    description: 'When the Android app or web client invokes verifyPhoneNumber() or signInWithPhoneNumber(), Firebase contacts the Identity Toolkit API. If the Phone sign-in provider is disabled, Firebase returns CONFIGURATION_NOT_FOUND.',
    exactResolution: [
      'Open the Firebase Console for your project.',
      'Navigate to Authentication -> Sign-in method tab.',
      'Locate "Phone" in the Sign-in providers table.',
      'Click Edit, toggle the "Enable" switch to ON, and click Save.',
      'Optionally expand "Phone numbers for testing" and add a test number (e.g. +92 300 0000000 with OTP 123456) to test without consuming SMS credits.'
    ],
    firebaseConsolePath: 'Authentication > Sign-in method > Phone',
    androidImpact: 'Fails immediately during PhoneAuthProvider.verifyPhoneNumber() on Android with FirebaseAuthException: [CONFIGURATION_NOT_FOUND]'
  },
  {
    code: 'MISSING_SHA_FINGERPRINT',
    title: 'Missing SHA-1 or SHA-256 Fingerprint in Android App Settings',
    severity: 'CRITICAL',
    description: 'Firebase Phone Auth on Android relies on Google Play Integrity / SafetyNet and SMS Retriever API. To verify your app identity without reCAPTCHA fallbacks, Firebase MUST validate your signing certificate fingerprint. Without it, the Firebase backend cannot authenticate the request and raises CONFIGURATION_NOT_FOUND or INVALID_APP_CREDENTIAL.',
    exactResolution: [
      'Generate your SHA-1 and SHA-256 keys by running in your Android project terminal: ./gradlew signingReport (or inspect your release keystore keytool -list -v -keystore your_key.jks).',
      'Go to Firebase Console -> Project Settings -> General tab.',
      'Scroll down to "Your apps" section and select your Android app (e.g. com.aistudio.jphone.qkzvtb).',
      'Click "Add fingerprint" and paste both your SHA-1 and SHA-256 fingerprints.',
      'IMPORTANT: If you use Google Play App Signing, also copy the SHA-1 from Google Play Console -> Release -> Setup -> App integrity -> App signing key certificate and add it to Firebase!',
      'Download the updated google-services.json file and place it in your Android app module (app/google-services.json).'
    ],
    firebaseConsolePath: 'Project Settings > General > Your apps > Android app > SHA certificate fingerprints',
    androidImpact: 'Silent SMS verification and Play Integrity tokens are rejected; Android device verification fails.'
  },
  {
    code: 'IDENTITY_TOOLKIT_API_DISABLED',
    title: 'Identity Toolkit API or Android Device Verification API Disabled in Google Cloud',
    severity: 'HIGH',
    description: 'Firebase Auth is powered under the hood by Google Cloud Identity Toolkit API (identitytoolkit.googleapis.com) and Play Integrity API. If the API key is restricted or the API was accidentally disabled in the Google Cloud Console, requests fail with CONFIGURATION_NOT_FOUND.',
    exactResolution: [
      'Open Google Cloud Console (console.cloud.google.com) with the same Google account.',
      'Select your Firebase project from the project dropdown.',
      'Navigate to APIs & Services -> Enabled APIs & Services.',
      'Confirm that "Identity Toolkit API" and "Play Integrity API" are ENABLED.',
      'Go to APIs & Services -> Credentials -> inspect "Android key (auto created by Firebase)" or browser key.',
      'Ensure API restrictions do not block Identity Toolkit API, Token Service API, or Firebase installations API.'
    ],
    firebaseConsolePath: 'Google Cloud Console > APIs & Services > Enabled APIs & Services',
    androidImpact: 'All authentication network calls are rejected at Google gateway level before reaching Firebase Auth.'
  },
  {
    code: 'PACKAGE_NAME_MISMATCH',
    title: 'Android Package Name / ApplicationId Mismatch in google-services.json',
    severity: 'HIGH',
    description: 'If the Android build uses an applicationId (e.g., com.aistudio.jphone.qkzvtb.debug or com.jphone.android) that does not exactly match the client package name registered in Firebase, Firebase configuration lookup fails.',
    exactResolution: [
      'Check app/build.gradle: verify defaultConfig { applicationId "com.aistudio.jphone.qkzvtb" }.',
      'Check google-services.json: verify client -> client_info -> android_client_info -> package_name is identical.',
      'If you have multiple build variants (debug/staging/release), add each package name as a separate Android app in Firebase Console under the same project.'
    ],
    firebaseConsolePath: 'Project Settings > General > Your apps',
    androidImpact: 'FirebaseApp.initializeApp(context) uses mismatched client info, causing credential verification errors.'
  },
  {
    code: 'RECAPTCHA_SMS_QUOTA_EXCEEDED',
    title: 'SMS Daily Quota Exceeded or Country Code Blocked',
    severity: 'MEDIUM',
    description: 'Firebase Spark (Free) plan includes 10 SMS verifications/day. Once reached, requests fail. Additionally, Firebase has SMS fraud prevention regions.',
    exactResolution: [
      'Check Firebase Console -> Authentication -> Usage tab to check daily SMS volume.',
      'For development and QA, configure White-listed Phone Numbers in Sign-in method -> Phone -> "Phone numbers for testing". Test numbers do not count against quotas.',
      'If distributing to production, ensure the Firebase project is upgraded to the Blaze (pay-as-you-go) plan where SMS has a high monthly allowance.'
    ],
    firebaseConsolePath: 'Authentication > Usage & Sign-in method > Phone numbers for testing',
    androidImpact: 'User receives an error stating SMS could not be sent or verification attempt failed.'
  }
];

export async function runComprehensiveDiagnostics(): Promise<DiagnosticCheck[]> {
  const config = getStoredFirebaseConfig();
  const checks: DiagnosticCheck[] = [];

  // Check 1: Project Configuration
  if (!config) {
    checks.push({
      id: 'cfg_missing',
      name: 'Firebase Client Configuration',
      category: 'Firebase',
      status: 'warning',
      summary: 'Running in UI Preview / Sandbox Mode',
      details: 'No live Firebase project credentials detected in .env or web storage. Admin panel is displaying simulated preview records.',
      recommendation: 'Click "Configure Firebase" in the header to enter your API Key and Project ID, or configure .env with VITE_FIREBASE_API_KEY.'
    });
  } else {
    checks.push({
      id: 'cfg_present',
      name: 'Firebase Client Configuration',
      category: 'Firebase',
      status: 'success',
      summary: `Configured for Project: ${config.projectId}`,
      details: `Auth Domain: ${config.authDomain} | App ID: ${config.appId.slice(0, 14)}...`,
      recommendation: 'Configuration is loaded into the browser runtime.'
    });
  }

  // Check 2: Firestore Database Connectivity
  if (!config) {
    checks.push({
      id: 'firestore_offline',
      name: 'Cloud Firestore Connection',
      category: 'Firebase',
      status: 'warning',
      summary: 'Firestore Offline (Preview Sandbox Active)',
      details: 'Live database connection is paused until Firebase credentials are provided.',
      recommendation: 'Provide valid Project ID to initialize live Firestore queries.'
    });
  } else {
    try {
      const result = await testFirestoreConnection();
      checks.push({
        id: 'firestore_live',
        name: 'Cloud Firestore Connection',
        category: 'Firebase',
        status: result.connected ? 'success' : 'error',
        summary: result.connected ? 'Cloud Firestore Online' : 'Cloud Firestore Unreachable',
        details: result.message,
        recommendation: result.connected ? 'Database queries and rules enforcement are active.' : 'Check your internet connection, Firebase project ID, and firestore.rules.'
      });
    } catch (e: any) {
      checks.push({
        id: 'firestore_err',
        name: 'Cloud Firestore Connection',
        category: 'Firebase',
        status: 'error',
        summary: 'Cloud Firestore Error',
        details: String(e),
        recommendation: 'Verify Firebase Security Rules and Firestore database provisioning.'
      });
    }
  }

  // Check 3: Authentication Service Availability
  if (auth) {
    checks.push({
      id: 'auth_init',
      name: 'Firebase Authentication SDK',
      category: 'Auth',
      status: 'success',
      summary: 'Auth SDK Initialized',
      details: `Current User: ${auth.currentUser ? auth.currentUser.email || auth.currentUser.uid : 'No active session (Guest)'}`,
      recommendation: 'Ensure authorized domains in Firebase Console include this web host.'
    });
  } else {
    checks.push({
      id: 'auth_missing',
      name: 'Firebase Authentication SDK',
      category: 'Auth',
      status: 'warning',
      summary: 'Auth SDK in Preview Emulation',
      details: 'Real Firebase Auth requires valid Project ID & API Key.',
      recommendation: 'Configure your Firebase project credentials.'
    });
  }

  // Check 4: CONFIGURATION_NOT_FOUND Investigation Status
  checks.push({
    id: 'config_not_found_alert',
    name: 'Investigation: CONFIGURATION_NOT_FOUND',
    category: 'Android',
    status: 'error',
    summary: 'Root Cause: Android Phone Auth / SHA-1 Missing',
    details: 'This error occurs during Android Phone Verification because the Phone sign-in provider is disabled in Firebase Console or the Android SHA-1 fingerprint is not configured in Project Settings.',
    recommendation: 'Follow the 5-step checklist in the dedicated CONFIGURATION_NOT_FOUND troubleshooter below.'
  });

  // Check 5: Security Rules Enforcement
  checks.push({
    id: 'security_rules',
    name: 'Zero-Trust ABAC Security Rules',
    category: 'Security',
    status: 'success',
    summary: 'Hardened rules ready for deployment (Eight Pillars)',
    details: 'firestore.rules restricts administrative mutations to authenticated admins in /admins/{uid}. Ordinary users cannot escalate permissions or modify subscriptionTier.',
    recommendation: 'Deploy firestore.rules using the Firebase CLI (firebase deploy --only firestore:rules).'
  });

  return checks;
}
