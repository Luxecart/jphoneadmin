/** Firestore values (millis number, Timestamp, ISO string) -> ISO string */
export function toIso(v: any): string | undefined {
  if (v === null || v === undefined || v === '') return undefined;
  if (typeof v === 'number') return new Date(v).toISOString();
  if (typeof v === 'string') return v;
  if (typeof v?.toDate === 'function') return v.toDate().toISOString();
  return undefined;
}

/** Firestore rejects `undefined` values, so strip them before writing. */
export function clean<T>(obj: T): T {
  return JSON.parse(JSON.stringify(obj));
}
