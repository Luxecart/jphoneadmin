import { PushNotification } from '../types';
import { INITIAL_MOCK_NOTIFICATIONS } from './mockData';
import { db, auth, handleFirestoreError, OperationType } from './firebase';
import { collection, getDocs, doc, setDoc, query, orderBy, limit } from 'firebase/firestore';
import { recordAuditLog } from './auditService';
import { toIso, clean } from './utils';

let inMemoryNotifications: PushNotification[] = [...INITIAL_MOCK_NOTIFICATIONS];
const isLive = () => !!(db && auth?.currentUser);

// Android app collection: /admin_notifications/{id}  (title, body, topic, targetScreen, updateUrl, createdAt(millis), status)
const AUDIENCE_TO_TOPIC: Record<PushNotification['targetAudience'], string> = {
  all: 'all_users',
  free_users: 'free_users',
  premium_users: 'premium_users',
  topic_announcements: 'announcements'
};
const topicToAudience = (t: string): PushNotification['targetAudience'] =>
  (Object.keys(AUDIENCE_TO_TOPIC) as PushNotification['targetAudience'][]).find(k => AUDIENCE_TO_TOPIC[k] === t) ?? 'all';

export async function fetchNotifications(): Promise<{ notifications: PushNotification[]; isLive: boolean }> {
  if (isLive()) {
    try {
      const snap = await getDocs(query(collection(db!, 'admin_notifications'), orderBy('createdAt', 'desc'), limit(50)));
      const list: PushNotification[] = snap.docs.map(s => {
        const d: any = s.data();
        const st = String(d.status || '').toUpperCase();
        return {
          id: s.id,
          title: d.title ?? '',
          body: d.body ?? '',
          imageUrl: d.imageUrl,
          targetAudience: topicToAudience(d.topic),
          deepLink: d.targetScreen || d.updateUrl || undefined,
          sentAt: toIso(d.createdAt) ?? '',
          sentByAdminId: d.sentBy ?? '',
          status: st === 'FAILED' ? 'failed' : st === 'SENT' ? 'sent' : 'scheduled'
        };
      });
      return { notifications: list, isLive: true };
    } catch (err) {
      console.error('Notifications fetch failed:', err);
      return { notifications: [], isLive: true };
    }
  }
  return { notifications: inMemoryNotifications, isLive: false };
}

export async function sendBroadcastNotification(
  notification: Omit<PushNotification, 'id' | 'sentAt' | 'sentByAdminId' | 'status' | 'deliveryCount'>
): Promise<PushNotification> {
  const adminEmail = auth?.currentUser?.email || 'admin@jphone.app';
  const adminId = auth?.currentUser?.uid || 'admin_sys';
  const id = `notif_${Date.now()}`;
  const now = Date.now();

  const newNotif: PushNotification = {
    ...notification,
    id,
    sentAt: new Date(now).toISOString(),
    sentByAdminId: adminEmail,
    // Live mode mein status "queued" hai: FCM bhejne ke liye Cloud Function chahiye (README dekhein)
    status: isLive() ? 'scheduled' : 'sent'
  };

  if (isLive()) {
    try {
      await setDoc(doc(db!, 'admin_notifications', id), clean({
        title: notification.title,
        body: notification.body,
        topic: AUDIENCE_TO_TOPIC[notification.targetAudience],
        targetScreen: notification.deepLink || '',
        updateUrl: '',
        imageUrl: notification.imageUrl,
        createdAt: now,
        status: 'QUEUED',
        sentBy: adminEmail
      }));
    } catch (err) {
      handleFirestoreError(err, OperationType.CREATE, `admin_notifications/${id}`);
    }
  } else {
    newNotif.deliveryCount = 0;
    inMemoryNotifications = [newNotif, ...inMemoryNotifications];
  }

  await recordAuditLog({
    adminId, adminEmail,
    action: 'NOTIFICATION_BROADCAST',
    targetType: 'notification', targetId: id,
    summary: `Queued push notification "${notification.title}" for [${notification.targetAudience}]`,
    details: { title: notification.title, body: notification.body, targetAudience: notification.targetAudience, deepLink: notification.deepLink }
  });

  return newNotif;
}
