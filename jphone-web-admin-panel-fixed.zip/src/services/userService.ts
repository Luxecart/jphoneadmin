import { JPhoneUser, SubscriptionTier } from '../types';
import { INITIAL_MOCK_USERS } from './mockData';
import { db, auth, handleFirestoreError, OperationType } from './firebase';
import { collection, getDocs, doc, updateDoc, query, limit, setDoc } from 'firebase/firestore';
import { recordAuditLog } from './auditService';
import { toIso, clean } from './utils';

let inMemoryUsers: JPhoneUser[] = [...INITIAL_MOCK_USERS];
const isLive = () => !!(db && auth?.currentUser);

/**
 * Android app /users/{uid} document:
 *   displayName, phoneNumber, status (ACTIVE|SUSPENDED|PENDING_VERIFICATION),
 *   isPremium, premiumPlanId, premiumExpiryDate (millis), adminNotes, updatedAt (millis)
 */
function mapUser(id: string, d: any): JPhoneUser {
  const phone = d.phoneNumber ?? d.normalizedPhoneNumber;
  return {
    id,
    email: d.email,
    emailVerified: !!d.emailVerified,
    phoneNumber: phone,
    phoneVerified: !!phone,
    displayName: d.displayName,
    subscriptionTier: d.isPremium === true ? 'premium' : 'free',
    subscriptionExpiry: toIso(d.premiumExpiryDate) ?? null,
    isSuspended: String(d.status || '').toUpperCase() === 'SUSPENDED',
    createdAt: toIso(d.createdAt) ?? toIso(d.updatedAt) ?? new Date(0).toISOString(),
    lastSeenAt: toIso(d.updatedAt),
    adminNotes: d.adminNotes
  };
}

export async function fetchUsers(): Promise<{ users: JPhoneUser[]; isLive: boolean }> {
  if (isLive()) {
    try {
      const snap = await getDocs(query(collection(db!, 'users'), limit(200)));
      return { users: snap.docs.map(d => mapUser(d.id, d.data())), isLive: true };
    } catch (err) {
      console.error('Users fetch failed:', err);
      return { users: [], isLive: true };
    }
  }
  return { users: inMemoryUsers, isLive: false };
}

export async function updateUserSuspension(userId: string, isSuspended: boolean, reason?: string): Promise<void> {
  const adminEmail = auth?.currentUser?.email || 'admin@jphone.app';
  const adminId = auth?.currentUser?.uid || 'admin_sys';

  if (isLive()) {
    try {
      // Rules sirf in keys ki ijazat dete hain: status, adminNotes, isPremium, premiumPlanId, premiumExpiryDate, updatedAt
      await updateDoc(doc(db!, 'users', userId), {
        status: isSuspended ? 'SUSPENDED' : 'ACTIVE',
        updatedAt: Date.now()
      });
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `users/${userId}`);
    }
  } else {
    inMemoryUsers = inMemoryUsers.map(u => u.id === userId
      ? { ...u, isSuspended, suspendedReason: isSuspended ? (reason || 'Admin action') : undefined }
      : u);
  }

  await recordAuditLog({
    adminId, adminEmail,
    action: isSuspended ? 'USER_SUSPENDED' : 'USER_REACTIVATED',
    targetType: 'user', targetId: userId,
    summary: isSuspended ? `Suspended user account (Reason: ${reason || 'Unspecified'})` : 'Reactivated suspended user account',
    details: { isSuspended, reason }
  });
}

export async function updateUserSubscriptionTier(
  userId: string,
  tier: SubscriptionTier,
  durationDays: number = 30,
  reason: string = 'Admin complimentary grant'
): Promise<void> {
  const adminEmail = auth?.currentUser?.email || 'admin@jphone.app';
  const adminId = auth?.currentUser?.uid || 'admin_sys';
  const now = Date.now();
  const expiryMillis = tier === 'premium' ? now + durationDays * 86400000 : null;

  if (isLive()) {
    try {
      await updateDoc(doc(db!, 'users', userId), {
        isPremium: tier === 'premium',
        premiumPlanId: tier === 'premium' ? 'admin_complimentary' : null,
        premiumExpiryDate: expiryMillis,
        updatedAt: now
      });
      // Android app /subscriptions/{uid} (same shape as AdminManager.grantPromotionalPremium)
      await setDoc(doc(db!, 'subscriptions', userId), clean(tier === 'premium' ? {
        userId, isPremium: true, planId: 'admin_complimentary', planName: 'Complimentary Premium',
        durationDays, grantedBy: adminEmail, grantedAt: now, expiresAt: expiryMillis, grantReason: reason
      } : { userId, isPremium: false, revokedBy: adminEmail, revokedAt: now }), { merge: true });
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `users/${userId}`);
    }
  } else {
    inMemoryUsers = inMemoryUsers.map(u => u.id === userId
      ? { ...u, subscriptionTier: tier, subscriptionExpiry: expiryMillis ? new Date(expiryMillis).toISOString() : null }
      : u);
  }

  await recordAuditLog({
    adminId, adminEmail,
    action: tier === 'premium' ? 'PREMIUM_GRANTED' : 'PREMIUM_REVOKED',
    targetType: 'user', targetId: userId,
    summary: tier === 'premium' ? `Granted PREMIUM tier for ${durationDays} days. Reason: ${reason}` : 'Revoked PREMIUM tier back to FREE',
    details: { tier, durationDays, reason, expiry: expiryMillis }
  });
}

export async function updateUserNotes(userId: string, notes: string): Promise<void> {
  if (isLive()) {
    try {
      await updateDoc(doc(db!, 'users', userId), { adminNotes: notes, updatedAt: Date.now() });
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `users/${userId}`);
    }
  } else {
    inMemoryUsers = inMemoryUsers.map(u => u.id === userId ? { ...u, adminNotes: notes } : u);
  }
}
