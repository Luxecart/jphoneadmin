import { initializeApp, getApps, getApp, FirebaseApp } from 'firebase/app';
import { getAuth, Auth, GoogleAuthProvider, signInWithPopup, signOut as fbSignOut, onAuthStateChanged, User as FirebaseUser } from 'firebase/auth';
import { getFirestore, Firestore, doc, getDoc, getDocFromServer } from 'firebase/firestore';

export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
    tenantId?: string | null;
    providerInfo?: {
      providerId?: string | null;
      email?: string | null;
    }[];
  };
}

export interface FirebaseClientConfig {
  apiKey: string;
  authDomain: string;
  projectId: string;
  storageBucket: string;
  messagingSenderId: string;
  appId: string;
  measurementId?: string;
  firestoreDatabaseId?: string;
}

// Retrieve from localStorage or env
const STORAGE_KEY = 'jphone_firebase_config';

export function getStoredFirebaseConfig(): FirebaseClientConfig | null {
  const local = localStorage.getItem(STORAGE_KEY);
  if (local) {
    try {
      return JSON.parse(local);
    } catch {
      // fallback
    }
  }

  const envApiKey = import.meta.env.VITE_FIREBASE_API_KEY;
  const envProjectId = import.meta.env.VITE_FIREBASE_PROJECT_ID;

  if (envApiKey && envProjectId && envApiKey !== 'AIzaSyYourFirebaseApiKey') {
    return {
      apiKey: envApiKey,
      authDomain: import.meta.env.VITE_FIREBASE_AUTH_DOMAIN || `${envProjectId}.firebaseapp.com`,
      projectId: envProjectId,
      storageBucket: import.meta.env.VITE_FIREBASE_STORAGE_BUCKET || `${envProjectId}.appspot.com`,
      messagingSenderId: import.meta.env.VITE_FIREBASE_MESSAGING_SENDER_ID || '',
      appId: import.meta.env.VITE_FIREBASE_APP_ID || '',
      measurementId: import.meta.env.VITE_FIREBASE_MEASUREMENT_ID || '',
      firestoreDatabaseId: '(default)'
    };
  }

  return null;
}

export function saveFirebaseConfig(config: FirebaseClientConfig): void {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(config));
  window.location.reload();
}

export function clearFirebaseConfig(): void {
  localStorage.removeItem(STORAGE_KEY);
  window.location.reload();
}

let appInstance: FirebaseApp | null = null;
let authInstance: Auth | null = null;
let dbInstance: Firestore | null = null;

const currentConfig = getStoredFirebaseConfig();

if (currentConfig && currentConfig.apiKey && currentConfig.projectId) {
  try {
    appInstance = getApps().length === 0 ? initializeApp(currentConfig) : getApp();
    authInstance = getAuth(appInstance);
    dbInstance = getFirestore(appInstance);
  } catch (err) {
    console.warn('Firebase initialization error with provided credentials:', err);
  }
}

export const app = appInstance;
export const auth = authInstance;
export const db = dbInstance;

/**
 * Handle Firestore Error conforming strictly to FirestoreErrorInfo format
 */
export function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null): never {
  const currentUser = auth?.currentUser;
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    operationType,
    path,
    authInfo: {
      userId: currentUser?.uid || null,
      email: currentUser?.email || null,
      emailVerified: currentUser?.emailVerified || null,
      isAnonymous: currentUser?.isAnonymous || null,
      tenantId: currentUser?.tenantId || null,
      providerInfo: currentUser?.providerData?.map(p => ({
        providerId: p.providerId,
        email: p.email,
      })) || []
    }
  };

  console.error('Firestore Error:', JSON.stringify(errInfo, null, 2));
  throw new Error(JSON.stringify(errInfo));
}

/**
 * Test live Firestore connection directly against remote server
 */
export async function testFirestoreConnection(): Promise<{ connected: boolean; message: string; latencyMs?: number }> {
  if (!db) {
    return { connected: false, message: 'Firebase is not initialized. Please configure API key and Project ID.' };
  }
  const start = performance.now();
  try {
    // Attempt reading settings or connection doc
    await getDocFromServer(doc(db, 'app_config', 'general'));
    const latency = Math.round(performance.now() - start);
    return { connected: true, message: `Connected to Cloud Firestore (Latency: ${latency}ms)`, latencyMs: latency };
  } catch (err: any) {
    const message = err?.message || String(err);
    if (message.includes('the client is offline')) {
      return { connected: false, message: 'Firestore offline: verify network or database region.' };
    }
    if (message.includes('Missing or insufficient permissions') || message.includes('permission-denied')) {
      // Permission denied means connection succeeded to Firestore server, but security rules rejected unauthenticated request
      return { connected: true, message: 'Connected to Firestore server (Security rules active: permission denied for unauthenticated query as expected).' };
    }
    return { connected: false, message: `Connection test failed: ${message}` };
  }
}

/**
 * Admin Sign-in via Google Auth Provider
 */
export async function signInWithGoogle(): Promise<FirebaseUser | null> {
  if (!auth) {
    throw new Error('Firebase Authentication is not configured yet. Add your Firebase credentials first.');
  }
  const provider = new GoogleAuthProvider();
  provider.setCustomParameters({ prompt: 'select_account' });
  const result = await signInWithPopup(auth, provider);
  return result.user;
}

export async function signOutAdmin(): Promise<void> {
  if (auth) {
    await fbSignOut(auth);
  }
}


/** Auth state listener (login screen ke liye) */
export function subscribeAuth(cb: (user: FirebaseUser | null) => void): () => void {
  if (!auth) return () => {};
  return onAuthStateChanged(auth, cb);
}

/**
 * Admin check: /admins/{uid} sirf admin parh sakta hai (Firestore rules isAdmin()).
 * Read kamyab = admin; permission-denied = admin nahi.
 */
export async function checkIsAdmin(user: FirebaseUser): Promise<boolean> {
  if (!db) return false;
  try {
    await getDoc(doc(db, 'admins', user.uid));
    return true;
  } catch {
    return false;
  }
}
