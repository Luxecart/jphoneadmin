import { AppSettings } from '../types';
import { INITIAL_MOCK_SETTINGS } from './mockData';
import { db, auth, handleFirestoreError, OperationType } from './firebase';
import { doc, getDoc, setDoc } from 'firebase/firestore';
import { recordAuditLog } from './auditService';
import { clean } from './utils';

let inMemorySettings: AppSettings = { ...INITIAL_MOCK_SETTINGS };

// Android app collection: /app_config/{docId}  (public read, admin write)
//  - app_config/general          -> panel ki saari public settings
//  - app_config/advertising      -> Android AdManager ye doc parhta hai
//  - app_config/update_announcement
// Secret fields (maintenance bypass key, AppLovin key) public doc mein NAHI jaati;
// wo /admin_reports/panel_private_settings mein (sirf admin parh sakta hai).
const PRIVATE_KEYS = ['maintenanceBypassKey', 'appLovinKey'] as const;
const isLive = () => !!(db && auth?.currentUser);

export async function fetchAppSettings(): Promise<{ settings: AppSettings; isLive: boolean }> {
  if (isLive()) {
    try {
      const snap = await getDoc(doc(db!, 'app_config', 'general'));
      let priv: any = {};
      try {
        const p = await getDoc(doc(db!, 'admin_reports', 'panel_private_settings'));
        if (p.exists()) priv = p.data();
      } catch { /* ignore */ }
      if (snap.exists()) {
        return { settings: { ...INITIAL_MOCK_SETTINGS, ...(snap.data() as AppSettings), ...priv }, isLive: true };
      }
      return { settings: { ...INITIAL_MOCK_SETTINGS, ...priv }, isLive: true };
    } catch (err) {
      console.error('Settings fetch failed:', err);
      return { settings: { ...INITIAL_MOCK_SETTINGS }, isLive: true };
    }
  }
  return { settings: inMemorySettings, isLive: false };
}

export async function saveAppSettings(settings: AppSettings): Promise<void> {
  const adminEmail = auth?.currentUser?.email || 'admin@jphone.app';
  const adminId = auth?.currentUser?.uid || 'admin_sys';
  const now = Date.now();

  const updatedSettings: AppSettings = {
    ...settings,
    updatedAt: new Date(now).toISOString(),
    updatedBy: adminEmail
  };

  if (isLive()) {
    try {
      const pub: any = { ...updatedSettings };
      const priv: any = {};
      PRIVATE_KEYS.forEach(k => { priv[k] = pub[k]; delete pub[k]; });

      await setDoc(doc(db!, 'app_config', 'general'), clean(pub));
      await setDoc(doc(db!, 'admin_reports', 'panel_private_settings'), clean(priv));

      // Android AdManager ke fields
      await setDoc(doc(db!, 'app_config', 'advertising'), clean({
        isGlobalAdsEnabled: settings.adsEnabled,
        isTestMode: settings.testAdsMode,
        lastUpdatedAt: now,
        updatedBy: adminEmail
      }), { merge: true });

      // Android update announcement
      if (settings.latestVersion) {
        await setDoc(doc(db!, 'app_config', 'update_announcement'), clean({
          versionLabel: settings.latestVersion,
          updateUrl: settings.downloadUrl,
          isMandatory: settings.forceUpdate,
          publishedAt: now
        }), { merge: true });
      }
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, 'app_config/general');
    }
  } else {
    inMemorySettings = updatedSettings;
  }

  await recordAuditLog({
    adminId, adminEmail,
    action: 'SETTINGS_UPDATED',
    targetType: 'settings', targetId: 'general',
    summary: `Updated JPhone remote app settings (Maintenance: ${settings.maintenanceMode ? 'ON' : 'OFF'}, Ads: ${settings.adsEnabled ? 'ON' : 'OFF'})`,
    details: {
      appName: settings.appName,
      maintenanceMode: settings.maintenanceMode,
      minSupportedVersion: settings.minSupportedVersion,
      latestVersion: settings.latestVersion,
      whatsAppEnabled: settings.whatsAppEnabled
    }
  });
}

/**
 * Generates official Android Remote Config / Firebase client JSON
 */
export function generateAndroidRemoteConfigJson(settings: AppSettings): string {
  return JSON.stringify(
    {
      app_name: settings.appName,
      support_email: settings.supportEmail,
      support_whatsapp_number: settings.supportPhoneWhatsApp,
      whatsapp_enabled: settings.whatsAppEnabled,
      whatsapp_default_message: settings.whatsAppDefaultMessage,
      maintenance_mode: settings.maintenanceMode,
      maintenance_bypass_key: settings.maintenanceBypassKey,
      maintenance_message: settings.maintenanceMessage,
      min_supported_version: settings.minSupportedVersion,
      latest_version: settings.latestVersion,
      download_url: settings.downloadUrl,
      force_update: settings.forceUpdate,
      ads_enabled: settings.adsEnabled,
      test_ads_mode: settings.testAdsMode,
      admob_app_id: settings.adMobAppId,
      admob_banner_id: settings.adMobBannerId,
      admob_interstitial_id: settings.adMobInterstitialId,
      admob_rewarded_id: settings.adMobRewardedId,
      applovin_key: settings.appLovinKey,
      unity_game_id: settings.unityGameId,
      last_synced_at: new Date().toISOString()
    },
    null,
    2
  );
}
