import { JPhoneUser, Plan, Subscription, AppSettings, PushNotification, AuditLog } from '../types';

export const INITIAL_MOCK_USERS: JPhoneUser[] = [
  {
    id: 'usr_8923a1',
    displayName: 'Malik Ahmad',
    email: 'malik.ahmad@example.com',
    emailVerified: true,
    phoneNumber: '+923001234567',
    phoneVerified: true,
    subscriptionTier: 'premium',
    subscriptionExpiry: '2027-01-15T00:00:00Z',
    isSuspended: false,
    createdAt: '2026-03-12T10:14:00Z',
    lastSeenAt: '2026-10-19T18:32:00Z',
    adminNotes: 'VIP subscriber. Verified via Google Play Billing.'
  },
  {
    id: 'usr_9410b2',
    displayName: 'Sara Khan',
    email: 'sara.k@example.com',
    emailVerified: true,
    phoneNumber: '+923219876543',
    phoneVerified: true,
    subscriptionTier: 'free',
    subscriptionExpiry: null,
    isSuspended: false,
    createdAt: '2026-05-20T14:22:00Z',
    lastSeenAt: '2026-10-18T09:15:00Z',
    adminNotes: 'Requested VoIP feature support.'
  },
  {
    id: 'usr_3321c4',
    displayName: 'Zainab Fatima',
    email: 'zainab.f@example.com',
    emailVerified: false,
    phoneNumber: '+923334567890',
    phoneVerified: true,
    subscriptionTier: 'free',
    subscriptionExpiry: null,
    isSuspended: false,
    createdAt: '2026-07-01T08:00:00Z',
    lastSeenAt: '2026-10-19T11:45:00Z'
  },
  {
    id: 'usr_7712d9',
    displayName: 'Hamza Tariq',
    email: 'hamza.tariq@example.com',
    emailVerified: true,
    phoneNumber: '+923451122334',
    phoneVerified: false,
    subscriptionTier: 'premium',
    subscriptionExpiry: '2026-12-31T23:59:59Z',
    isSuspended: false,
    createdAt: '2026-01-10T16:40:00Z',
    lastSeenAt: '2026-10-19T19:01:00Z',
    adminNotes: 'Complimentary grant for beta testing.'
  },
  {
    id: 'usr_1029e7',
    displayName: 'Ayesha Noor',
    email: 'ayesha.noor@example.com',
    emailVerified: true,
    phoneNumber: '+923129988776',
    phoneVerified: true,
    subscriptionTier: 'free',
    subscriptionExpiry: null,
    isSuspended: true,
    suspendedReason: 'Repeated spam reports on community directory',
    createdAt: '2026-02-18T12:05:00Z',
    lastSeenAt: '2026-09-04T15:20:00Z',
    adminNotes: 'Suspended pending review.'
  },
  {
    id: 'usr_5544f8',
    displayName: 'Bilal Hassan',
    email: 'bilal.hassan@example.com',
    emailVerified: false,
    phoneNumber: '+923015556677',
    phoneVerified: false,
    subscriptionTier: 'free',
    subscriptionExpiry: null,
    isSuspended: false,
    createdAt: '2026-10-15T09:30:00Z',
    lastSeenAt: '2026-10-15T09:35:00Z'
  }
];

export const INITIAL_MOCK_PLANS: Plan[] = [
  {
    id: 'plan_monthly_pro',
    name: 'JPhone Pro Monthly',
    code: 'jphone_pro_monthly',
    price: 4.99,
    currency: 'USD',
    durationDays: 30,
    description: 'Ad-free caller ID, unlimited call recording, priority routing and custom dialer themes.',
    features: ['Zero Ads', 'HD Call Recording', 'Smart Spam Protection', 'Custom Dialer Themes', 'Priority Support'],
    isActive: true,
    updatedAt: '2026-09-01T12:00:00Z',
    updatedBy: 'admin_sys'
  },
  {
    id: 'plan_annual_vip',
    name: 'JPhone VIP Annual',
    code: 'jphone_vip_annual',
    price: 39.99,
    currency: 'USD',
    durationDays: 365,
    description: 'Full year of all premium benefits at a 33% discount with WhatsApp concierge support.',
    features: ['Zero Ads', 'HD Call Recording', 'Cloud Call Backups', 'WhatsApp Concierge Support', 'Early Access to Beta Features'],
    isActive: true,
    updatedAt: '2026-09-01T12:00:00Z',
    updatedBy: 'admin_sys'
  },
  {
    id: 'plan_lifetime_supporter',
    name: 'Founder Lifetime Pass',
    code: 'jphone_founder_lifetime',
    price: 99.00,
    currency: 'USD',
    durationDays: 3650,
    description: 'Lifetime access to all future JPhone features with exclusive Founder badge.',
    features: ['Permanent Premium Access', 'Founder In-App Badge', 'Direct Developer Hotline'],
    isActive: false,
    updatedAt: '2026-08-15T10:00:00Z',
    updatedBy: 'admin_sys'
  }
];

export const INITIAL_MOCK_SETTINGS: AppSettings = {
  appName: 'JPhone',
  supportEmail: 'support@jphone.app',
  supportPhoneWhatsApp: '+923001234567',
  whatsAppEnabled: true,
  whatsAppDefaultMessage: 'Hello JPhone Support Team, I need assistance with my app account.',
  maintenanceMode: false,
  maintenanceBypassKey: 'jphone_dev_preview_2026',
  maintenanceMessage: 'JPhone services are temporarily undergoing scheduled maintenance to improve network quality. Please check back shortly.',
  minSupportedVersion: '1.2.0',
  latestVersion: '1.4.2',
  downloadUrl: 'https://play.google.com/store/apps/details?id=com.aistudio.jphone.qkzvtb',
  forceUpdate: false,
  adsEnabled: true,
  testAdsMode: true,
  adMobAppId: 'ca-app-pub-3940256099942544~3347511713',
  adMobBannerId: 'ca-app-pub-3940256099942544/6300978111',
  adMobInterstitialId: 'ca-app-pub-3940256099942544/1033173712',
  adMobRewardedId: 'ca-app-pub-3940256099942544/5224354917',
  appLovinKey: 'SDK_KEY_DEMO_APPLOVIN',
  unityGameId: '5432100',
  updatedAt: '2026-10-18T14:00:00Z',
  updatedBy: 'attamuhammad6008@gmail.com'
};

export const INITIAL_MOCK_NOTIFICATIONS: PushNotification[] = [
  {
    id: 'notif_001',
    title: 'New HD Caller ID Update Available!',
    body: 'Version 1.4.2 includes enhanced spam detection and lightning-fast contact lookup. Tap to update.',
    targetAudience: 'all',
    deepLink: 'jphone://settings/update',
    sentAt: '2026-10-17T12:00:00Z',
    sentByAdminId: 'attamuhammad6008@gmail.com',
    status: 'sent',
    deliveryCount: 14250
  },
  {
    id: 'notif_002',
    title: 'Unlock JPhone Pro for 30% Off',
    body: 'Enjoy zero ads, cloud call backup, and instant WhatsApp support this week only.',
    targetAudience: 'free_users',
    deepLink: 'jphone://premium',
    sentAt: '2026-10-14T15:30:00Z',
    sentByAdminId: 'attamuhammad6008@gmail.com',
    status: 'sent',
    deliveryCount: 8400
  }
];

export const INITIAL_MOCK_AUDIT_LOGS: AuditLog[] = [
  {
    id: 'log_901',
    adminId: 'attamuhammad6008@gmail.com',
    adminEmail: 'attamuhammad6008@gmail.com',
    action: 'LOGIN',
    targetType: 'auth',
    targetId: 'attamuhammad6008@gmail.com',
    summary: 'Administrator successfully authenticated via secure portal',
    timestamp: '2026-10-19T18:45:00Z'
  },
  {
    id: 'log_902',
    adminId: 'attamuhammad6008@gmail.com',
    adminEmail: 'attamuhammad6008@gmail.com',
    action: 'PREMIUM_GRANTED',
    targetType: 'user',
    targetId: 'usr_7712d9',
    summary: 'Granted complimentary JPhone Pro membership (Reason: Beta testing feedback)',
    timestamp: '2026-10-19T17:10:00Z',
    details: { durationDays: 90, tier: 'premium' }
  },
  {
    id: 'log_903',
    adminId: 'attamuhammad6008@gmail.com',
    adminEmail: 'attamuhammad6008@gmail.com',
    action: 'SETTINGS_UPDATED',
    targetType: 'settings',
    targetId: 'general',
    summary: 'Updated WhatsApp support number and switched ads to test mode',
    timestamp: '2026-10-18T14:00:00Z'
  }
];
